# Claude Code / Codex Prompt: Bannerwake Armor Archive Use

You are working on Bannerwake, a private Bannerlord overhaul. Use the generated armor archive as the source of truth for armor selection and recolor planning.

Input files:

```text
catalog/armor_catalog.csv
catalog/armor_catalog.json
reports/recolor_candidates.md
reports/armor_missing_screenshots.md
gallery/armor_gallery.html
screenshots/
```

Rules:

1. Preserve exact vanilla/mod item IDs.
2. Do not rename existing item IDs.
3. Bannerwake duplicate assets must use `bw_` prefix.
4. Do not assume `UseTeamColor` works unless the archive says true and visual testing confirms it.
5. If `UseTeamColor` is UNKNOWN, mark the item as needing a `bw_` material/texture variant when faction colors matter.
6. Black Keel requires heavy recolor: tar black, charcoal, dead sea-brown, corroded iron, ashen cloth, no clean bright metal.
7. Empire armor must be verified for Northern/Southern/Western palette behavior.
8. Human visual review overrides heuristic tags.

Tasks:

- Build faction candidate lists from the archive.
- Identify missing silhouettes per troop tree.
- Identify recolor candidates.
- Produce a final `BANNERWAKE_ARMOR_ASSIGNMENTS.md` with item IDs, troop usage, recolor status, and screenshot paths.

Never invent item IDs. If an item is not in the archive, mark it MISSING.
