# Bannerwake Armor Archivist v2 — Fully Automated Visual + Data Capture

This kit has two parts:

1. **External Python Archivist**
   - scans Bannerlord XML
   - builds `armor_catalog.csv` / `armor_catalog.json`
   - builds `capture_queue.json`
   - builds `armor_gallery.html`
   - exports `capture_queue.tsv` for the in-game capture module

2. **BannerwakeArmorAutoCapture in-game module + PowerShell watcher**
   - the in-game module equips one item at a time on a mannequin/agent
   - it rotates front/side/back depending on config
   - it writes a `ready.txt` signal
   - the PowerShell watcher captures the Bannerlord window automatically
   - screenshots are saved with correct item-ID filenames
   - rerun the Archivist scan and the HTML gallery becomes visual

Important: Python cannot render Bannerlord armor by itself. The actual 3D render must happen inside Bannerlord or the Modding Kit. This kit automates that process.

---

## Folder layout

```txt
bannerwake_armor_archivist_v2/
  bannerwake_armor_archivist.py
  tools/
    01_SCAN_AND_PREPARE_AUTOCAPTURE.bat
    02_BUILD_AND_INSTALL_CAPTURE_MOD.ps1
    03_START_SCREENSHOT_WATCHER.ps1
  BannerwakeArmorAutoCapture/
    SubModule.xml
    Source/BannerwakeArmorAutoCapture/*.cs
  config_templates/config.ini
```

---

## Step 1 — Extract

Extract this whole folder to:

```txt
C:\BannerwakeArmorArchivist
```

---

## Step 2 — Scan XML and prepare queue

Double-click:

```txt
tools\01_SCAN_AND_PREPARE_AUTOCAPTURE.bat
```

This creates:

```txt
C:\BannerwakeArmorArchive\catalog\armor_catalog.csv
C:\BannerwakeArmorArchive\catalog\armor_catalog.json
C:\BannerwakeArmorArchive\catalog\capture_queue.json
%USERPROFILE%\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture\capture_queue.tsv
%USERPROFILE%\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture\config.ini
```

Open/edit this if needed:

```txt
%USERPROFILE%\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture\config.ini
```

For fastest first run use:

```ini
Views=front
```

For full visual capture use:

```ini
Views=front,side,back
```

---

## Step 3 — Build and install the in-game capture module

Open PowerShell **as normal user** and run:

```powershell
cd C:\BannerwakeArmorArchivist
Set-ExecutionPolicy -Scope Process Bypass
.\tools\02_BUILD_AND_INSTALL_CAPTURE_MOD.ps1
```

If Bannerlord is not in the default Steam folder:

```powershell
.\tools\02_BUILD_AND_INSTALL_CAPTURE_MOD.ps1 -BannerlordDir "D:\SteamLibrary\steamapps\common\Mount & Blade II Bannerlord"
```

Then open the Bannerlord launcher and enable:

```txt
Bannerwake Armor AutoCapture
```

---

## Step 4 — Start the screenshot watcher

Open a second PowerShell window:

```powershell
cd C:\BannerwakeArmorArchivist
Set-ExecutionPolicy -Scope Process Bypass
.\tools\03_START_SCREENSHOT_WATCHER.ps1
```

Keep this watcher open. It waits for the in-game module to say: “item is ready, screenshot now.”

---

## Step 5 — Start Bannerlord and begin capture

In Bannerlord:

1. Start a campaign/custom battle/training mission — any scene where your player agent exists.
2. Stand in a clear flat area.
3. Keep the camera pointed at the empty space in front of you.
4. Press:

```txt
Ctrl + F9 = start / stop automated capture
Ctrl + F10 = capture one item manually
Ctrl + F11 = clear spawned mannequin
Ctrl + F12 = reload config + queue
```

The module will:

- load the queue
- spawn one mannequin in front of you
- equip one armor item
- rotate according to view
- signal the watcher
- wait for screenshot acknowledgement
- move to the next item automatically

Screenshots are saved to:

```txt
C:\BannerwakeArmorArchive\screenshots\front
C:\BannerwakeArmorArchive\screenshots\side
C:\BannerwakeArmorArchive\screenshots\back
```

---

## Step 6 — Rebuild the gallery with screenshots

After capture, run:

```powershell
cd C:\BannerwakeArmorArchivist
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\workshop\content\261550" `
  --screenshots-root "C:\BannerwakeArmorArchive\screenshots" `
  --out "C:\BannerwakeArmorArchive" `
  --views front side back
```

Then open:

```txt
C:\BannerwakeArmorArchive\gallery\armor_gallery.html
```

Now it should show visual armor cards.

---

## Recommended first capture pass

Do not start with front/side/back for everything. First run:

```ini
Views=front
```

After the front archive is done, use the visual gallery to choose only good candidates for side/back.

---

## Resume after crash

If Bannerlord crashes at item 742, edit `config.ini`:

```ini
StartIndex=742
```

Press Ctrl+F12 in game, then Ctrl+F9 again.

---

## What to give Claude/Codex

Give it:

```txt
C:\BannerwakeArmorArchive\catalog\armor_catalog.csv
C:\BannerwakeArmorArchive\catalog\armor_catalog.json
C:\BannerwakeArmorArchive\reports\recolor_candidates.md
C:\BannerwakeArmorArchive\gallery\armor_gallery.html
C:\BannerwakeArmorArchive\screenshots\
```

Then ask it to classify armor for Bannerwake factions and mark recolor/duplicate needs.
