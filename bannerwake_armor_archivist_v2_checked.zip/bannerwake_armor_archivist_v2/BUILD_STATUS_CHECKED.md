# Bannerwake Armor Archivist v2 — Checked Status

Checked in ChatGPT container on 2026-06-05.

## Verified here

- ZIP integrity: OK.
- Python CLI loads: OK.
- Python XML scan on a small test module: OK.
- CSV/JSON/gallery/capture_queue generation: OK.
- AutoCapture TSV export from JSON queue: OK.

## Not fully verifiable here

- The C# Bannerlord mission module cannot be truly compiled in this container because your local Bannerlord v1.4.5 / War Sails DLLs are not present.
- The in-game visual spawn/capture loop must be validated on your PC with `tools/00_PREFLIGHT_CHECK.ps1` first.

## Important fix made after review

- Removed per-item in-game notification messages before screenshots. The screenshot watcher captures the Bannerlord window, so per-item UI messages would contaminate armor screenshots.

## Recommended build order

1. Run `tools\01_SCAN_AND_PREPARE_AUTOCAPTURE.bat`.
2. Run `tools\00_PREFLIGHT_CHECK.ps1`.
3. Only if the preflight build succeeds, run `tools\02_BUILD_AND_INSTALL_CAPTURE_MOD.ps1`.
4. Start `tools\03_START_SCREENSHOT_WATCHER.ps1`.
5. Start Bannerlord, enable the module, enter a scene, press Ctrl+F9.
6. After capture, run `tools\04_REBUILD_GALLERY_AFTER_CAPTURE.bat`.

If preflight fails, send the build errors back before trying to launch the module.
