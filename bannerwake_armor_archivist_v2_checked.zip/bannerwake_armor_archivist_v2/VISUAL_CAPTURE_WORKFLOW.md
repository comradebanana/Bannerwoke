# Visual Capture Workflow for Bannerwake Armor Archivist

The archivist handles the data and gallery. For screenshots, use any visual source you trust:

- Bannerlord Modding Kit scene/editor
- Item Viewer mod
- your existing AssetInspector / AutoScreenshotter workflow
- manual screenshots

## Best screenshot standard

Use the same setup for every armor:

- same mannequin
- same lighting
- same background
- same camera distance
- same pose
- front view minimum
- side/back for important armor

## Automatic/sequential workflow

1. Run the archive scan first.
2. Open `catalog/capture_queue.json`.
3. Capture items in exactly that order.
4. Save raw images into folders like:

```text
C:\RawBannerlordScreenshots\front
C:\RawBannerlordScreenshots\side
C:\RawBannerlordScreenshots\back
```

5. Link them:

```powershell
python .\bannerwake_armor_archivist.py link-screenshots `
  --queue "C:\BannerwakeArmorArchive\catalog\capture_queue.json" `
  --raw-screenshots "C:\RawBannerlordScreenshots\front" `
  --out "C:\BannerwakeArmorArchive" `
  --view front
```

6. Rerun scan with screenshots:

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --screenshots-root "C:\BannerwakeArmorArchive\screenshots" `
  --out "C:\BannerwakeArmorArchive"
```

7. Open:

```text
C:\BannerwakeArmorArchive\gallery\armor_gallery.html
```

## Why this matters for Claude/Codex

Claude/Codex should not pick armor from names alone. It needs:

- exact item ID
- exact source module
- mesh/material clue
- armor stats
- screenshot
- recolor judgment
- Bannerwake faction candidate

That is why this archive produces both machine-readable data and a human visual gallery.
