#!/usr/bin/env python3
"""
Bannerwake Armor Archivist
==========================
External data + visual archive builder for Mount & Blade II: Bannerlord armor items.

What it does:
- Scans Bannerlord module folders for XML <Item> records.
- Extracts armor/shield/horse-armor data into CSV + JSON.
- Detects likely team-color support from XML flags/attributes.
- Finds matching screenshots by item_id and view name.
- Generates Markdown reports and a self-contained HTML gallery.
- Generates a capture_queue.json for in-game/modding-kit screenshot workflows.
- Optionally links/renames sequential screenshots to item IDs using the queue order.

No Bannerlord DLLs required. Python 3.10+ recommended. No third-party packages required.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import html
import json
import os
import re
import shutil
import sys
import traceback
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
ARMOR_TYPES = {
    "HeadArmor",
    "BodyArmor",
    "Cape",
    "Shoulder",
    "HandArmor",
    "LegArmor",
    "HorseHarness",
    "HorseArmor",
    "Shield",
}
ARMOR_SLOT_ORDER = {
    "HeadArmor": 10,
    "BodyArmor": 20,
    "Cape": 30,
    "Shoulder": 31,
    "HandArmor": 40,
    "LegArmor": 50,
    "HorseHarness": 60,
    "HorseArmor": 61,
    "Shield": 70,
    "UnknownArmor": 99,
}

DEFAULT_EXCLUDE_DIR_KEYWORDS = {
    "languages",
    "language",
    "voice",
    "voices",
    "music",
    "sound",
    "sounds",
    "atmospheres",
    "prefabs",
    "gui",
}

BANNERWAKE_FACTION_COLOR_HINTS = {
    "sturgia": "Sturgia: FF1C2A50 / FF949CCC",
    "vlandia": "Vlandia: FF5C2017 / FFECBA44",
    "battania": "Battania: FF2D3F1D / FFBFCBB0",
    "aserai": "Aserai: FF965228 / FF4F2212",
    "khuzait": "Khuzait: FF468C7C / FFCCBB89",
    "empire": "Empire: owner-dependent purple/gold variants",
    "nord": "Nords: FF202931 / FFb7623c",
    "pirate": "Black Keel candidate: tar black / charcoal / dead sea-brown / corroded iron",
}


def now_stamp() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def strip_ns(tag: str) -> str:
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def norm_key(s: str | None) -> str:
    if not s:
        return ""
    s = s.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return s.strip("_")


def clean_text_id_name(raw: str | None) -> str:
    if not raw:
        return ""
    # Bannerlord names often look like {=abc123}Name
    return re.sub(r"^\{=[^}]+\}", "", raw).strip()


def boolish(value: str | None) -> Optional[bool]:
    if value is None:
        return None
    v = str(value).strip().lower()
    if v in {"true", "1", "yes"}:
        return True
    if v in {"false", "0", "no"}:
        return False
    return None


def number_or_blank(value: str | None) -> str:
    return "" if value is None else str(value)


def safe_rel(path: Path, base: Path) -> str:
    try:
        return str(path.relative_to(base)).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def discover_modules(roots: List[Path], include_modules: List[str], exclude_modules: List[str]) -> List[Path]:
    include_norm = {norm_key(x) for x in include_modules if x.strip()}
    exclude_norm = {norm_key(x) for x in exclude_modules if x.strip()}
    found: Dict[str, Path] = {}

    for root in roots:
        if not root.exists():
            print(f"[WARN] Modules root does not exist: {root}", file=sys.stderr)
            continue

        candidates: List[Path] = []
        if (root / "SubModule.xml").exists():
            candidates.append(root)
        else:
            try:
                for child in root.iterdir():
                    if child.is_dir() and (child / "SubModule.xml").exists():
                        candidates.append(child)
            except PermissionError:
                print(f"[WARN] Permission denied while reading: {root}", file=sys.stderr)

        for mod_path in candidates:
            mod_key = norm_key(mod_path.name)
            if exclude_norm and mod_key in exclude_norm:
                continue
            if include_norm and mod_key not in include_norm:
                # Also allow case-insensitive exact raw folder name match.
                if mod_path.name.lower() not in {x.lower() for x in include_modules}:
                    continue
            found[mod_key] = mod_path

    return [found[k] for k in sorted(found.keys())]


def should_skip_xml(xml_path: Path, include_all_xml: bool) -> bool:
    if include_all_xml:
        return False
    parts = {p.lower() for p in xml_path.parts}
    if parts & DEFAULT_EXCLUDE_DIR_KEYWORDS:
        return True
    name = xml_path.name.lower()
    if "language" in name or "strings" in name or "voice" in name:
        return True
    return False


@dataclass
class ArmorRecord:
    item_id: str
    display_name_raw: str = ""
    display_name_clean: str = ""
    source_module: str = ""
    source_xml: str = ""
    item_type: str = ""
    slot: str = ""
    culture: str = ""
    mesh: str = ""
    body_mesh: str = ""
    holster_mesh: str = ""
    multi_mesh: str = ""
    material: str = ""
    material_type: str = ""
    physics_material: str = ""
    weight: str = ""
    value: str = ""
    difficulty: str = ""
    appearance: str = ""
    tier: str = ""
    modifier_group: str = ""
    item_usage: str = ""
    is_merchandise: str = ""
    use_team_color: str = "UNKNOWN"
    civilian: str = ""
    multiplayer_item: str = ""
    cannot_be_picked_up: str = ""
    head_armor: str = ""
    body_armor: str = ""
    arm_armor: str = ""
    leg_armor: str = ""
    horse_armor: str = ""
    shield_hit_points: str = ""
    covers_body: str = ""
    covers_legs: str = ""
    has_flags_node: str = ""
    raw_flag_names: str = ""
    visual_bucket: str = ""
    bannerwake_candidate_faction: str = ""
    bannerwake_recolor_needed: str = "UNKNOWN"
    recolor_reason: str = ""
    screenshot_front: str = ""
    screenshot_side: str = ""
    screenshot_back: str = ""
    screenshot_detail: str = ""
    notes: str = ""

    def sort_key(self) -> Tuple[str, int, str]:
        return (self.source_module.lower(), ARMOR_SLOT_ORDER.get(self.slot, 999), self.item_id.lower())


class BannerlordXmlScanner:
    def __init__(self, module_paths: List[Path], out_dir: Path, include_all_xml: bool = False):
        self.module_paths = module_paths
        self.out_dir = out_dir
        self.include_all_xml = include_all_xml
        self.errors: List[str] = []
        self.records: List[ArmorRecord] = []

    def scan(self) -> List[ArmorRecord]:
        print(f"[INFO] Scanning {len(self.module_paths)} module(s)...")
        for module_path in self.module_paths:
            self._scan_module(module_path)
        # Deduplicate by source_module + item_id + source_xml, but keep duplicates across modules.
        unique: Dict[Tuple[str, str, str], ArmorRecord] = {}
        for r in self.records:
            unique[(r.source_module, r.item_id, r.source_xml)] = r
        self.records = sorted(unique.values(), key=lambda r: r.sort_key())
        print(f"[INFO] Found {len(self.records)} armor/shield records.")
        return self.records

    def _scan_module(self, module_path: Path) -> None:
        module_name = module_path.name
        xml_files = [p for p in module_path.rglob("*.xml") if not should_skip_xml(p, self.include_all_xml)]
        print(f"[INFO] {module_name}: {len(xml_files)} XML files considered")
        for xml_path in xml_files:
            self._scan_xml(module_path, xml_path)

    def _scan_xml(self, module_path: Path, xml_path: Path) -> None:
        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
        except Exception as exc:
            self.errors.append(f"XML parse failed: {xml_path} :: {exc}")
            return

        for elem in root.iter():
            if strip_ns(elem.tag) != "Item":
                continue
            record = self._parse_item(module_path, xml_path, elem)
            if record:
                self.records.append(record)

    def _parse_item(self, module_path: Path, xml_path: Path, item: ET.Element) -> Optional[ArmorRecord]:
        attrs = {k: v for k, v in item.attrib.items()}
        item_id = attrs.get("id") or attrs.get("ID") or attrs.get("Id")
        if not item_id:
            return None

        item_type = attrs.get("Type") or attrs.get("type") or attrs.get("subtype") or ""
        armor_elem = None
        weapon_elem = None
        flags_elem = None
        flag_names: List[str] = []
        extra_attrs: Dict[str, str] = {}

        for child in item.iter():
            tag = strip_ns(child.tag)
            if tag == "Armor":
                armor_elem = child
            elif tag == "Weapon":
                weapon_elem = child
            elif tag == "Flags":
                flags_elem = child
                for k, v in child.attrib.items():
                    if str(v).lower() in {"true", "1", "yes"}:
                        flag_names.append(k)
            elif tag in {"ItemComponent", "ItemFlags"}:
                pass
            # Some modules store useful fields in nested nodes. Keep a few common values.
            for k, v in child.attrib.items():
                lk = k.lower()
                if lk in {
                    "mesh", "body_mesh", "holster_mesh", "multi_mesh", "material", "material_type",
                    "physics_material", "modifier_group", "item_usage", "hit_points",
                }:
                    extra_attrs.setdefault(k, v)

        # Include shields even though they are Weapon components, because recoloring shields matters.
        is_shield = False
        if weapon_elem is not None:
            wc = weapon_elem.attrib.get("weapon_class", "") or weapon_elem.attrib.get("WeaponClass", "")
            is_shield = "shield" in wc.lower() or "shield" in item_type.lower()

        armor_attrs = armor_elem.attrib if armor_elem is not None else {}
        if armor_elem is None and not is_shield and item_type not in ARMOR_TYPES:
            # Catch likely armor by id/file names only if it has armor-ish type.
            return None

        slot = self._infer_slot(item_type, attrs, armor_attrs, is_shield)
        if slot == "UnknownArmor" and not is_shield:
            return None

        use_team_color = self._detect_team_color(attrs, flags_elem, flag_names, item)
        culture = attrs.get("culture", "") or attrs.get("Culture", "")
        visual_bucket, candidate, recolor_needed, reason = self._classify_for_bannerwake(
            item_id=item_id,
            name=attrs.get("name", ""),
            source_module=module_path.name,
            culture=culture,
            item_type=item_type,
            use_team_color=use_team_color,
        )

        r = ArmorRecord(
            item_id=item_id,
            display_name_raw=attrs.get("name", ""),
            display_name_clean=clean_text_id_name(attrs.get("name", "")),
            source_module=module_path.name,
            source_xml=safe_rel(xml_path, module_path),
            item_type=item_type,
            slot=slot,
            culture=culture.replace("Culture.", ""),
            mesh=attrs.get("mesh", "") or extra_attrs.get("mesh", ""),
            body_mesh=attrs.get("body_mesh", "") or extra_attrs.get("body_mesh", ""),
            holster_mesh=attrs.get("holster_mesh", "") or extra_attrs.get("holster_mesh", ""),
            multi_mesh=attrs.get("multi_mesh", "") or extra_attrs.get("multi_mesh", ""),
            material=attrs.get("material", "") or extra_attrs.get("material", ""),
            material_type=armor_attrs.get("material_type", "") or extra_attrs.get("material_type", ""),
            physics_material=attrs.get("physics_material", "") or extra_attrs.get("physics_material", ""),
            weight=number_or_blank(attrs.get("weight")),
            value=number_or_blank(attrs.get("value")),
            difficulty=number_or_blank(attrs.get("difficulty")),
            appearance=number_or_blank(attrs.get("appearance")),
            tier=number_or_blank(attrs.get("tier") or attrs.get("Tier")),
            modifier_group=attrs.get("modifier_group", "") or extra_attrs.get("modifier_group", ""),
            item_usage=attrs.get("item_usage", "") or extra_attrs.get("item_usage", ""),
            is_merchandise=number_or_blank(attrs.get("is_merchandise")),
            use_team_color=use_team_color,
            civilian="true" if "Civilian" in flag_names else number_or_blank(attrs.get("civilian")),
            multiplayer_item="true" if "MultiplayerItem" in flag_names else number_or_blank(attrs.get("multiplayer_item")),
            cannot_be_picked_up="true" if "CannotBePickedUp" in flag_names else "",
            head_armor=number_or_blank(armor_attrs.get("head_armor")),
            body_armor=number_or_blank(armor_attrs.get("body_armor")),
            arm_armor=number_or_blank(armor_attrs.get("arm_armor")),
            leg_armor=number_or_blank(armor_attrs.get("leg_armor")),
            horse_armor=number_or_blank(armor_attrs.get("horse_armor")),
            shield_hit_points=number_or_blank((weapon_elem.attrib.get("hit_points") if weapon_elem is not None else "") or extra_attrs.get("hit_points", "")),
            covers_body=number_or_blank(armor_attrs.get("covers_body")),
            covers_legs=number_or_blank(armor_attrs.get("covers_legs")),
            has_flags_node="true" if flags_elem is not None else "false",
            raw_flag_names=";".join(sorted(set(flag_names))),
            visual_bucket=visual_bucket,
            bannerwake_candidate_faction=candidate,
            bannerwake_recolor_needed=recolor_needed,
            recolor_reason=reason,
        )
        return r

    def _infer_slot(self, item_type: str, attrs: Dict[str, str], armor_attrs: Dict[str, str], is_shield: bool) -> str:
        if is_shield:
            return "Shield"
        if item_type in ARMOR_TYPES:
            if item_type == "Shoulder":
                return "Cape"
            return item_type
        # Infer from armor values.
        values = {k: armor_attrs.get(k, "") for k in ["head_armor", "body_armor", "arm_armor", "leg_armor", "horse_armor"]}
        if values.get("horse_armor"):
            return "HorseArmor"
        if values.get("head_armor") and not values.get("body_armor"):
            return "HeadArmor"
        if values.get("body_armor"):
            return "BodyArmor"
        if values.get("arm_armor") and not values.get("body_armor"):
            return "HandArmor"
        if values.get("leg_armor") and not values.get("body_armor"):
            return "LegArmor"
        id_name = (attrs.get("id", "") + " " + attrs.get("name", "") + " " + attrs.get("mesh", "")).lower()
        if "helmet" in id_name or "helm" in id_name:
            return "HeadArmor"
        if "boot" in id_name or "shoe" in id_name or "leg" in id_name:
            return "LegArmor"
        if "glove" in id_name or "hand" in id_name:
            return "HandArmor"
        if "cape" in id_name or "cloak" in id_name or "shoulder" in id_name:
            return "Cape"
        if "armor" in id_name or "mail" in id_name or "lamellar" in id_name or "robe" in id_name:
            return "BodyArmor"
        return "UnknownArmor"

    def _detect_team_color(self, attrs: Dict[str, str], flags_elem: Optional[ET.Element], flag_names: List[str], item: ET.Element) -> str:
        # Common Bannerlord item flag.
        if "UseTeamColor" in flag_names:
            return "true"
        for k, v in attrs.items():
            if k.lower() in {"use_team_color", "useteamcolor", "use_tableau"}:
                b = boolish(v)
                if b is True:
                    return "true"
                if b is False:
                    return "false"
        if flags_elem is not None:
            for k, v in flags_elem.attrib.items():
                if k.lower() == "useteamcolor":
                    b = boolish(v)
                    if b is True:
                        return "true"
                    if b is False:
                        return "false"
        # Some modules use color2/color tags in material/mesh nodes. Treat as clues, not proof.
        xml_text = ET.tostring(item, encoding="unicode", method="xml").lower()
        if "teamcolor" in xml_text or "team_color" in xml_text or "bannercolor" in xml_text:
            return "LIKELY"
        return "UNKNOWN"

    def _classify_for_bannerwake(
        self,
        item_id: str,
        name: str,
        source_module: str,
        culture: str,
        item_type: str,
        use_team_color: str,
    ) -> Tuple[str, str, str, str]:
        text = norm_key(" ".join([item_id, name, source_module, culture, item_type]))
        bucket = "generic"
        candidate = ""
        reasons: List[str] = []
        for key, label in BANNERWAKE_FACTION_COLOR_HINTS.items():
            if key in text:
                bucket = key
                candidate = label
                break
        if "vlandian" in text or "vlandia" in text:
            bucket = "vlandia"
            candidate = BANNERWAKE_FACTION_COLOR_HINTS["vlandia"]
        if "battan" in text:
            bucket = "battania"
            candidate = BANNERWAKE_FACTION_COLOR_HINTS["battania"]
        if "aserai" in text or "maml" in text or "arab" in text:
            bucket = "aserai"
            candidate = BANNERWAKE_FACTION_COLOR_HINTS["aserai"]
        if "khuzait" in text or "steppe" in text or "mongol" in text:
            bucket = "khuzait"
            candidate = BANNERWAKE_FACTION_COLOR_HINTS["khuzait"]
        if "imperial" in text or "empire" in text:
            bucket = "empire"
            candidate = BANNERWAKE_FACTION_COLOR_HINTS["empire"]
        if "nord" in text or "viking" in text or "norse" in text:
            bucket = "nord"
            candidate = BANNERWAKE_FACTION_COLOR_HINTS["nord"]
        if "pirate" in text or "raider" in text or "sea" in text or "corsair" in text:
            if bucket in {"generic", "nord", "sturgia"}:
                bucket = "pirate"
                candidate = BANNERWAKE_FACTION_COLOR_HINTS["pirate"]

        recolor = "UNKNOWN"
        if use_team_color == "true":
            recolor = "maybe_not"
            reasons.append("UseTeamColor present; test in-game before duplicating texture.")
        elif use_team_color == "LIKELY":
            recolor = "verify"
            reasons.append("Dynamic color clue found, but not proven.")
        else:
            recolor = "likely"
            reasons.append("No confirmed UseTeamColor flag; likely needs bw_ material/texture variant if faction-colored.")

        if bucket == "pirate":
            recolor = "heavy"
            reasons.append("Pirate/sea asset: candidate for Black Keel dark salt-weathered palette.")
        if bucket == "empire":
            reasons.append("Empire tree needs owner-dependent Northern/Southern/Western palette verification.")
        if source_module.lower() not in {"native", "sandbox", "sandboxcore", "storymode", "custombattle", "navaldlc"}:
            reasons.append("External mod asset; verify permission/private-use notes and texture quality.")
        return bucket, candidate, recolor, " ".join(reasons)


class ScreenshotLinker:
    def __init__(self, screenshot_roots: List[Path], out_dir: Path):
        self.screenshot_roots = [p for p in screenshot_roots if p and p.exists()]
        self.out_dir = out_dir
        self.index: Dict[str, List[Path]] = {}
        self._build_index()

    def _build_index(self) -> None:
        for root in self.screenshot_roots:
            for path in root.rglob("*"):
                if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS:
                    key = norm_key(path.stem)
                    self.index.setdefault(key, []).append(path)

    def attach(self, records: List[ArmorRecord]) -> None:
        for r in records:
            matches = self._find_matches(r.item_id)
            views = self._classify_views(matches)
            r.screenshot_front = self._to_gallery_path(views.get("front"))
            r.screenshot_side = self._to_gallery_path(views.get("side"))
            r.screenshot_back = self._to_gallery_path(views.get("back"))
            r.screenshot_detail = self._to_gallery_path(views.get("detail"))

    def _find_matches(self, item_id: str) -> List[Path]:
        needle = norm_key(item_id)
        matches: List[Path] = []
        for key, paths in self.index.items():
            if key == needle or key.startswith(needle + "_") or ("_" + needle + "_") in ("_" + key + "_"):
                matches.extend(paths)
        return sorted(set(matches), key=lambda p: str(p).lower())

    def _classify_views(self, matches: List[Path]) -> Dict[str, Path]:
        views: Dict[str, Path] = {}
        for p in matches:
            k = norm_key(p.stem)
            if "front" in k and "front" not in views:
                views["front"] = p
            elif "side" in k and "side" not in views:
                views["side"] = p
            elif "back" in k and "back" not in views:
                views["back"] = p
            elif ("detail" in k or "close" in k) and "detail" not in views:
                views["detail"] = p
        # If only one image exists, use it as front.
        if matches and "front" not in views:
            views["front"] = matches[0]
        return views

    def _to_gallery_path(self, path: Optional[Path]) -> str:
        if not path:
            return ""
        # If already under out_dir, use relative; otherwise keep absolute file URI-ish path for local HTML.
        try:
            return safe_rel(path, self.out_dir)
        except Exception:
            return str(path).replace("\\", "/")


def write_csv(records: List[ArmorRecord], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(asdict(records[0]).keys()) if records else list(ArmorRecord(item_id="").__dict__.keys())
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in records:
            writer.writerow(asdict(r))


def write_json(records: List[ArmorRecord], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump([asdict(r) for r in records], f, ensure_ascii=False, indent=2)


def group_counts(records: List[ArmorRecord], key: str) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for r in records:
        value = getattr(r, key) or "UNKNOWN"
        counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].lower())))


def write_markdown_reports(records: List[ArmorRecord], out_dir: Path, errors: List[str], module_paths: List[Path]) -> None:
    reports = out_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)

    summary = reports / "archive_summary.md"
    with summary.open("w", encoding="utf-8") as f:
        f.write("# Bannerwake Armor Archive Summary\n\n")
        f.write(f"Generated: {now_stamp()}\n\n")
        f.write(f"Total records: **{len(records)}**\n\n")
        f.write("## Scanned modules\n\n")
        for p in module_paths:
            f.write(f"- `{p}`\n")
        f.write("\n## By source module\n\n")
        for k, v in group_counts(records, "source_module").items():
            f.write(f"- {k}: {v}\n")
        f.write("\n## By slot\n\n")
        for k, v in group_counts(records, "slot").items():
            f.write(f"- {k}: {v}\n")
        f.write("\n## By visual bucket\n\n")
        for k, v in group_counts(records, "visual_bucket").items():
            f.write(f"- {k}: {v}\n")
        f.write("\n## XML parse errors\n\n")
        if errors:
            for e in errors[:500]:
                f.write(f"- `{e}`\n")
            if len(errors) > 500:
                f.write(f"\n...and {len(errors)-500} more.\n")
        else:
            f.write("None.\n")

    by_module = reports / "armor_by_module.md"
    with by_module.open("w", encoding="utf-8") as f:
        f.write("# Armor By Module\n\n")
        current = None
        for r in sorted(records, key=lambda x: (x.source_module.lower(), x.slot, x.item_id.lower())):
            if r.source_module != current:
                current = r.source_module
                f.write(f"\n## {current}\n\n")
            f.write(f"- `{r.item_id}` — {r.slot}; culture `{r.culture or 'UNKNOWN'}`; mesh `{r.mesh or r.body_mesh or 'UNKNOWN'}`; team color `{r.use_team_color}`\n")

    by_culture = reports / "armor_by_culture.md"
    with by_culture.open("w", encoding="utf-8") as f:
        f.write("# Armor By Culture / Visual Bucket\n\n")
        current = None
        for r in sorted(records, key=lambda x: ((x.culture or x.visual_bucket or "UNKNOWN").lower(), x.slot, x.item_id.lower())):
            key = r.culture or r.visual_bucket or "UNKNOWN"
            if key != current:
                current = key
                f.write(f"\n## {current}\n\n")
            f.write(f"- `{r.item_id}` — {r.source_module}/{r.slot}; recolor `{r.bannerwake_recolor_needed}`\n")

    missing = reports / "armor_missing_screenshots.md"
    with missing.open("w", encoding="utf-8") as f:
        f.write("# Missing Screenshots\n\n")
        f.write("Items with no linked front screenshot. Generate or rename screenshots using `capture_queue.json`.\n\n")
        for r in records:
            if not r.screenshot_front:
                f.write(f"- `{r.item_id}` — {r.source_module}/{r.slot}\n")

    recolor = reports / "recolor_candidates.md"
    with recolor.open("w", encoding="utf-8") as f:
        f.write("# Recolor Candidates\n\n")
        f.write("Generated heuristically. Human visual review still wins.\n\n")
        for r in records:
            if r.bannerwake_recolor_needed in {"likely", "heavy", "verify"}:
                f.write(f"## `{r.item_id}`\n\n")
                f.write(f"- Source: {r.source_module}/{r.source_xml}\n")
                f.write(f"- Slot: {r.slot}\n")
                f.write(f"- Culture: {r.culture or 'UNKNOWN'}\n")
                f.write(f"- Mesh: `{r.mesh or r.body_mesh or 'UNKNOWN'}`\n")
                f.write(f"- Team color: {r.use_team_color}\n")
                f.write(f"- Candidate faction: {r.bannerwake_candidate_faction or r.visual_bucket}\n")
                f.write(f"- Reason: {r.recolor_reason}\n\n")


def write_capture_queue(records: List[ArmorRecord], path: Path, views: List[str]) -> None:
    queue = []
    for index, r in enumerate(records, start=1):
        base_slot = norm_key(r.slot or "armor")
        entry = {
            "order": index,
            "item_id": r.item_id,
            "display_name": r.display_name_clean or r.display_name_raw,
            "source_module": r.source_module,
            "slot": r.slot,
            "culture": r.culture,
            "mesh": r.mesh or r.body_mesh,
            "views": {
                view: f"{base_slot}__{r.item_id}__{view}.png" for view in views
            },
        }
        queue.append(entry)
    with path.open("w", encoding="utf-8") as f:
        json.dump(queue, f, ensure_ascii=False, indent=2)


def write_autocapture_tsv_from_queue(queue_json: Path, out_tsv: Path, views: List[str], limit: int = 0, slots: Optional[List[str]] = None) -> None:
    """Export a simple TSV consumed by the BannerwakeArmorAutoCapture in-game module."""
    data = json.loads(queue_json.read_text(encoding="utf-8"))
    allowed_slots = {norm_key(x) for x in (slots or []) if x.strip()}
    out_tsv.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with out_tsv.open("w", encoding="utf-8", newline="") as f:
        f.write("order\titem_id\tslot\tfilename_front\tfilename_side\tfilename_back\tfilename_detail\tdisplay_name\tsource_module\n")
        for entry in data:
            slot = entry.get("slot", "") or "UnknownArmor"
            if allowed_slots and norm_key(slot) not in allowed_slots:
                continue
            views_map = entry.get("views", {}) or {}
            row = [
                str(entry.get("order", "")),
                str(entry.get("item_id", "")),
                slot,
                str(views_map.get("front", "")),
                str(views_map.get("side", "")),
                str(views_map.get("back", "")),
                str(views_map.get("detail", "")),
                str(entry.get("display_name", "")).replace("\t", " "),
                str(entry.get("source_module", "")).replace("\t", " "),
            ]
            f.write("\t".join(row) + "\n")
            count += 1
            if limit and count >= limit:
                break
    print(f"[DONE] AutoCapture TSV written: {out_tsv} ({count} item(s))")


def img_tag(src: str, alt: str) -> str:
    if not src:
        return '<div class="noimg">no screenshot</div>'
    # Spaces in local relative URLs work in browser mostly, but encode minimally.
    safe_src = html.escape(src.replace("\\", "/"), quote=True)
    return f'<img loading="lazy" src="{safe_src}" alt="{html.escape(alt, quote=True)}">'


def write_html_gallery(records: List[ArmorRecord], path: Path) -> None:
    data_json = json.dumps([asdict(r) for r in records], ensure_ascii=False)
    cards = []
    for r in records:
        image = r.screenshot_front or r.screenshot_side or r.screenshot_back or r.screenshot_detail
        card = f"""
        <article class="card" data-id="{html.escape(norm_key(r.item_id))}" data-module="{html.escape(norm_key(r.source_module))}" data-slot="{html.escape(norm_key(r.slot))}" data-culture="{html.escape(norm_key(r.culture or r.visual_bucket))}" data-recolor="{html.escape(norm_key(r.bannerwake_recolor_needed))}">
          <div class="thumb">{img_tag(image, r.item_id)}</div>
          <div class="cardbody">
            <h3>{html.escape(r.item_id)}</h3>
            <p class="name">{html.escape(r.display_name_clean or r.display_name_raw or '')}</p>
            <dl>
              <dt>Module</dt><dd>{html.escape(r.source_module)}</dd>
              <dt>Slot</dt><dd>{html.escape(r.slot)}</dd>
              <dt>Culture</dt><dd>{html.escape(r.culture or 'UNKNOWN')}</dd>
              <dt>Mesh</dt><dd><code>{html.escape(r.mesh or r.body_mesh or 'UNKNOWN')}</code></dd>
              <dt>Armor</dt><dd>H {html.escape(r.head_armor or '-')} / B {html.escape(r.body_armor or '-')} / A {html.escape(r.arm_armor or '-')} / L {html.escape(r.leg_armor or '-')}</dd>
              <dt>Team color</dt><dd>{html.escape(r.use_team_color)}</dd>
              <dt>Recolor</dt><dd>{html.escape(r.bannerwake_recolor_needed)}</dd>
            </dl>
            <details><summary>Notes / source</summary>
              <p>{html.escape(r.recolor_reason)}</p>
              <p><code>{html.escape(r.source_xml)}</code></p>
              <p>Front: <code>{html.escape(r.screenshot_front or '')}</code></p>
              <p>Side: <code>{html.escape(r.screenshot_side or '')}</code></p>
              <p>Back: <code>{html.escape(r.screenshot_back or '')}</code></p>
            </details>
          </div>
        </article>
        """
        cards.append(card)

    html_text = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bannerwake Armor Gallery</title>
<style>
:root {{ --bg:#111; --panel:#1b1b1b; --soft:#282828; --text:#eee; --muted:#aaa; --line:#3a3a3a; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; font-family:Segoe UI, Arial, sans-serif; background:var(--bg); color:var(--text); }}
header {{ position:sticky; top:0; z-index:10; background:#0b0b0bcc; backdrop-filter: blur(8px); border-bottom:1px solid var(--line); padding:16px; }}
h1 {{ margin:0 0 8px; font-size:22px; }}
.controls {{ display:grid; grid-template-columns: 2fr repeat(4, minmax(140px, 1fr)); gap:8px; }}
input, select, button {{ width:100%; padding:9px 10px; border:1px solid var(--line); border-radius:8px; background:#181818; color:var(--text); }}
main {{ padding:16px; }}
.stats {{ color:var(--muted); margin:8px 0 16px; }}
.grid {{ display:grid; grid-template-columns: repeat(auto-fill, minmax(310px, 1fr)); gap:14px; }}
.card {{ background:var(--panel); border:1px solid var(--line); border-radius:14px; overflow:hidden; display:flex; min-height:220px; }}
.thumb {{ width:42%; background:#0d0d0d; display:flex; align-items:center; justify-content:center; border-right:1px solid var(--line); min-height:220px; }}
.thumb img {{ max-width:100%; max-height:240px; object-fit:contain; display:block; }}
.noimg {{ color:#666; font-size:13px; text-align:center; padding:12px; }}
.cardbody {{ padding:12px; width:58%; }}
h3 {{ margin:0 0 4px; font-size:15px; overflow-wrap:anywhere; }}
.name {{ color:var(--muted); margin:0 0 8px; font-size:13px; }}
dl {{ display:grid; grid-template-columns:80px 1fr; gap:3px 8px; font-size:12px; margin:0; }}
dt {{ color:var(--muted); }}
dd {{ margin:0; overflow-wrap:anywhere; }}
code {{ color:#d7d7d7; background:var(--soft); padding:1px 3px; border-radius:4px; }}
details {{ margin-top:8px; color:var(--muted); font-size:12px; }}
summary {{ cursor:pointer; color:#ddd; }}
.hidden {{ display:none !important; }}
@media (max-width: 900px) {{ .controls {{ grid-template-columns:1fr 1fr; }} .card {{ flex-direction:column; }} .thumb,.cardbody {{ width:100%; border-right:0; }} }}
</style>
</head>
<body>
<header>
  <h1>Bannerwake Armor Gallery</h1>
  <div class="controls">
    <input id="q" placeholder="Search item id, name, mesh, source...">
    <select id="module"><option value="">All modules</option></select>
    <select id="slot"><option value="">All slots</option></select>
    <select id="culture"><option value="">All cultures/buckets</option></select>
    <select id="recolor"><option value="">All recolor states</option></select>
  </div>
  <div class="stats"><span id="shown">0</span> shown / {len(records)} total</div>
</header>
<main><section class="grid" id="grid">{''.join(cards)}</section></main>
<script>
const DATA = {data_json};
function norm(s) {{ return (s||'').toString().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,''); }}
function addOptions(id, values) {{
  const sel = document.getElementById(id);
  [...new Set(values.filter(Boolean).map(norm))].sort().forEach(v => {{
    const opt = document.createElement('option'); opt.value=v; opt.textContent=v; sel.appendChild(opt);
  }});
}}
addOptions('module', DATA.map(x=>x.source_module));
addOptions('slot', DATA.map(x=>x.slot));
addOptions('culture', DATA.map(x=>x.culture || x.visual_bucket));
addOptions('recolor', DATA.map(x=>x.bannerwake_recolor_needed));
const inputs = ['q','module','slot','culture','recolor'].map(id=>document.getElementById(id));
function apply() {{
  const q = norm(document.getElementById('q').value);
  const mod = document.getElementById('module').value;
  const slot = document.getElementById('slot').value;
  const culture = document.getElementById('culture').value;
  const recolor = document.getElementById('recolor').value;
  let shown = 0;
  document.querySelectorAll('.card').forEach(card => {{
    const raw = norm(card.textContent);
    const ok = (!q || raw.includes(q)) && (!mod || card.dataset.module===mod) && (!slot || card.dataset.slot===slot) && (!culture || card.dataset.culture===culture) && (!recolor || card.dataset.recolor===recolor);
    card.classList.toggle('hidden', !ok);
    if (ok) shown++;
  }});
  document.getElementById('shown').textContent = shown;
}}
inputs.forEach(el => el.addEventListener('input', apply));
apply();
</script>
</body>
</html>
"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html_text, encoding="utf-8")


def sorted_images(folder: Path) -> List[Path]:
    imgs = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS]
    # Prefer natural-ish filename order; mtime fallback not stable after copy, so name order first.
    def natural_key(p: Path):
        return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", p.name)]
    return sorted(imgs, key=natural_key)


def link_sequential_screenshots(queue_path: Path, raw_folder: Path, out_dir: Path, view: str, copy_mode: bool = True) -> Path:
    if not queue_path.exists():
        raise FileNotFoundError(f"Queue not found: {queue_path}")
    if not raw_folder.exists():
        raise FileNotFoundError(f"Raw screenshot folder not found: {raw_folder}")
    queue = json.loads(queue_path.read_text(encoding="utf-8"))
    images = sorted_images(raw_folder)
    if not images:
        raise RuntimeError(f"No images found in {raw_folder}")
    target_root = out_dir / "screenshots" / view
    target_root.mkdir(parents=True, exist_ok=True)
    count = min(len(queue), len(images))
    manifest = []
    for i in range(count):
        entry = queue[i]
        src = images[i]
        slot = norm_key(entry.get("slot", "armor")) or "armor"
        filename = entry.get("views", {}).get(view) or f"{slot}__{entry['item_id']}__{view}{src.suffix.lower()}"
        if not Path(filename).suffix:
            filename += src.suffix.lower()
        dst = target_root / filename
        if copy_mode:
            shutil.copy2(src, dst)
        else:
            shutil.move(str(src), str(dst))
        manifest.append({"order": i + 1, "item_id": entry.get("item_id"), "source_image": str(src), "linked_image": str(dst)})
    manifest_path = out_dir / "reports" / f"linked_screenshots_{view}.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[INFO] Linked {count} screenshot(s) for view '{view}'. Manifest: {manifest_path}")
    if len(images) != len(queue):
        print(f"[WARN] Queue has {len(queue)} item(s), raw folder has {len(images)} image(s). Linked {count}.", file=sys.stderr)
    return manifest_path


def write_readme(path: Path) -> None:
    text = r"""# Bannerwake Armor Archivist

A local Windows-friendly tool for building a complete Bannerlord armor archive for Claude Code / Codex.

It creates:

- `catalog/armor_catalog.csv`
- `catalog/armor_catalog.json`
- `catalog/capture_queue.json`
- `reports/archive_summary.md`
- `reports/armor_by_module.md`
- `reports/armor_by_culture.md`
- `reports/recolor_candidates.md`
- `reports/armor_missing_screenshots.md`
- `gallery/armor_gallery.html`

## 1. Install Python

Install Python 3.10+ from python.org or Microsoft Store.

Check:

```powershell
python --version
```

## 2. Basic scan

Edit paths for your PC:

```powershell
cd C:\BannerwakeArmorArchivist
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --out "C:\BannerwakeArmorArchive"
```

This scans every module folder under the Modules root that has a `SubModule.xml`.

## 3. Scan only selected modules

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --include-modules Native SandBox SandBoxCore StoryMode CustomBattle NavalDLC OpenSourceArmory OpenSourceSaddlery VlandianSteel `
  --out "C:\BannerwakeArmorArchive"
```

## 4. Include Workshop mods too

Steam Workshop modules often live here:

```text
C:\Program Files (x86)\Steam\steamapps\workshop\content\261550
```

Use both roots:

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\workshop\content\261550" `
  --out "C:\BannerwakeArmorArchive"
```

## 5. Add screenshots

The tool links screenshots by item ID if filenames contain the item ID and view name.

Recommended names:

```text
bodyarmor__sturgia_lamellar_a__front.png
bodyarmor__sturgia_lamellar_a__side.png
bodyarmor__sturgia_lamellar_a__back.png
```

Then run:

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --screenshots-root "C:\BannerwakeArmorScreenshots" `
  --out "C:\BannerwakeArmorArchive"
```

Open:

```text
C:\BannerwakeArmorArchive\gallery\armor_gallery.html
```

## 6. Sequential screenshot workflow

If your in-game screenshotter dumps images as:

```text
screenshot_0001.png
screenshot_0002.png
screenshot_0003.png
```

use the generated `capture_queue.json` to rename/copy them to item IDs.

First scan to create queue:

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --out "C:\BannerwakeArmorArchive"
```

Then after capturing front-view screenshots in the same order:

```powershell
python .\bannerwake_armor_archivist.py link-screenshots `
  --queue "C:\BannerwakeArmorArchive\catalog\capture_queue.json" `
  --raw-screenshots "C:\RawBannerlordScreenshots\front" `
  --out "C:\BannerwakeArmorArchive" `
  --view front
```

Repeat for side/back if you captured those views:

```powershell
python .\bannerwake_armor_archivist.py link-screenshots --queue "C:\BannerwakeArmorArchive\catalog\capture_queue.json" --raw-screenshots "C:\RawBannerlordScreenshots\side" --out "C:\BannerwakeArmorArchive" --view side
python .\bannerwake_armor_archivist.py link-screenshots --queue "C:\BannerwakeArmorArchive\catalog\capture_queue.json" --raw-screenshots "C:\RawBannerlordScreenshots\back" --out "C:\BannerwakeArmorArchive" --view back
```

Then rerun `scan` with the archive screenshot folder:

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --screenshots-root "C:\BannerwakeArmorArchive\screenshots" `
  --out "C:\BannerwakeArmorArchive"
```

## 7. How to use with Claude/Codex

Give Claude/Codex these files:

```text
catalog/armor_catalog.csv
catalog/armor_catalog.json
reports/recolor_candidates.md
reports/armor_missing_screenshots.md
gallery/armor_gallery.html
```

For visual work, also give the screenshot folder.

## 8. Important Bannerwake rule

The tool guesses recolor need, but human review wins.

- `UseTeamColor=true` = probably dynamic color capable, still test in game.
- `UseTeamColor=UNKNOWN` = likely needs `bw_` material/texture variant if faction-colored.
- pirate/sea assets = marked as heavy Black Keel candidates by default.
- Empire assets = need owner-color verification because Northern/Southern/Western use different palettes.

Do not rename vanilla IDs. Bannerwake duplicates should use `bw_` prefix.
"""
    path.write_text(text, encoding="utf-8")


def create_default_batch(path: Path) -> None:
    text = r"""@echo off
setlocal
REM Edit these paths for your computer.
set MODULES=C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules
set WORKSHOP=C:\Program Files (x86)\Steam\steamapps\workshop\content\261550
set OUT=C:\BannerwakeArmorArchive
set SCREENSHOTS=C:\BannerwakeArmorArchive\screenshots

python "%~dp0bannerwake_armor_archivist.py" scan ^
  --modules-root "%MODULES%" ^
  --modules-root "%WORKSHOP%" ^
  --screenshots-root "%SCREENSHOTS%" ^
  --out "%OUT%"

if exist "%OUT%\gallery\armor_gallery.html" start "" "%OUT%\gallery\armor_gallery.html"
pause
"""
    path.write_text(text, encoding="utf-8")


def run_scan(args: argparse.Namespace) -> int:
    out_dir = Path(args.out).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    module_roots = [Path(p).expanduser() for p in args.modules_root]
    module_paths = discover_modules(module_roots, args.include_modules or [], args.exclude_modules or [])
    if not module_paths:
        print("[ERROR] No modules found. Check --modules-root path(s) and --include-modules names.", file=sys.stderr)
        return 2

    scanner = BannerlordXmlScanner(module_paths, out_dir, include_all_xml=args.include_all_xml)
    records = scanner.scan()

    screenshot_roots = [Path(p).expanduser() for p in (args.screenshots_root or [])]
    if screenshot_roots:
        ScreenshotLinker(screenshot_roots, out_dir).attach(records)

    catalog = out_dir / "catalog"
    gallery = out_dir / "gallery"
    catalog.mkdir(parents=True, exist_ok=True)
    gallery.mkdir(parents=True, exist_ok=True)

    write_csv(records, catalog / "armor_catalog.csv")
    write_json(records, catalog / "armor_catalog.json")
    write_capture_queue(records, catalog / "capture_queue.json", views=args.views)
    write_markdown_reports(records, out_dir, scanner.errors, module_paths)
    write_html_gallery(records, gallery / "armor_gallery.html")
    write_readme(out_dir / "README_BANNERWAKE_ARMOR_ARCHIVE.md")

    print("\n[DONE] Bannerwake armor archive generated:")
    print(f"  CSV:     {catalog / 'armor_catalog.csv'}")
    print(f"  JSON:    {catalog / 'armor_catalog.json'}")
    print(f"  Queue:   {catalog / 'capture_queue.json'}")
    print(f"  Reports: {out_dir / 'reports'}")
    print(f"  Gallery: {gallery / 'armor_gallery.html'}")
    return 0


def run_link(args: argparse.Namespace) -> int:
    out_dir = Path(args.out).expanduser().resolve()
    queue = Path(args.queue).expanduser().resolve()
    raw = Path(args.raw_screenshots).expanduser().resolve()
    link_sequential_screenshots(queue, raw, out_dir, args.view, copy_mode=not args.move)
    return 0


def run_export_autocapture(args: argparse.Namespace) -> int:
    queue = Path(args.queue).expanduser().resolve()
    out_tsv = Path(args.out_tsv).expanduser().resolve()
    write_autocapture_tsv_from_queue(queue, out_tsv, views=args.views, limit=args.limit, slots=args.slots)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Bannerwake Armor Archivist: XML data + visual gallery builder")
    sub = parser.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="Scan Bannerlord modules and generate CSV/JSON/reports/gallery")
    scan.add_argument("--modules-root", action="append", required=True, help="Bannerlord Modules root or Workshop content root. Can be repeated.")
    scan.add_argument("--include-modules", nargs="*", default=[], help="Only scan these module folder names. Omit to scan all discovered modules.")
    scan.add_argument("--exclude-modules", nargs="*", default=[], help="Exclude these module folder names.")
    scan.add_argument("--screenshots-root", action="append", default=[], help="Folder containing screenshots. Can be repeated.")
    scan.add_argument("--out", required=True, help="Output archive folder.")
    scan.add_argument("--include-all-xml", action="store_true", help="Also parse language/gui/prefab XML. Slower and noisier.")
    scan.add_argument("--views", nargs="*", default=["front", "side", "back"], help="Views to include in capture_queue.json")
    scan.set_defaults(func=run_scan)

    link = sub.add_parser("link-screenshots", help="Map sequential raw screenshots to capture_queue item IDs")
    link.add_argument("--queue", required=True, help="Path to capture_queue.json")
    link.add_argument("--raw-screenshots", required=True, help="Folder with sequential raw screenshot images")
    link.add_argument("--out", required=True, help="Output archive folder")
    link.add_argument("--view", choices=["front", "side", "back", "detail"], default="front", help="Which view these raw screenshots represent")
    link.add_argument("--move", action="store_true", help="Move instead of copy raw screenshots")
    link.set_defaults(func=run_link)

    auto = sub.add_parser("export-autocapture", help="Export capture_queue.json to TSV for the in-game AutoCapture module")
    auto.add_argument("--queue", required=True, help="Path to capture_queue.json")
    auto.add_argument("--out-tsv", required=True, help="Output capture_queue.tsv path")
    auto.add_argument("--views", nargs="*", default=["front", "side", "back"], help="Views to include. Filename columns are always present.")
    auto.add_argument("--limit", type=int, default=0, help="Optional max number of items for test runs")
    auto.add_argument("--slots", nargs="*", default=[], help="Optional slots to include, e.g. BodyArmor HeadArmor Cape Shield")
    auto.set_defaults(func=run_export_autocapture)

    init = sub.add_parser("init", help="Create README and sample batch file in current folder")
    init.add_argument("--out", default=".", help="Folder to write helper files into")
    def run_init(args: argparse.Namespace) -> int:
        out = Path(args.out).expanduser().resolve()
        out.mkdir(parents=True, exist_ok=True)
        write_readme(out / "README.md")
        create_default_batch(out / "RUN_BANNERWAKE_ARMOR_SCAN.bat")
        print(f"[DONE] Wrote README.md and RUN_BANNERWAKE_ARMOR_SCAN.bat to {out}")
        return 0
    init.set_defaults(func=run_init)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\n[ABORTED]", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
