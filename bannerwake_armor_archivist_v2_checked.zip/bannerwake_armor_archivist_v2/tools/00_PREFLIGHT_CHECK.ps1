param(
  [string]$BannerlordDir = "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord"
)

$ErrorActionPreference = "Continue"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$project = Join-Path $root "BannerwakeArmorAutoCapture\Source\BannerwakeArmorAutoCapture\BannerwakeArmorAutoCapture.csproj"
$bin = Join-Path $BannerlordDir "bin\Win64_Shipping_Client"
$needed = @(
  "TaleWorlds.Core.dll",
  "TaleWorlds.InputSystem.dll",
  "TaleWorlds.Library.dll",
  "TaleWorlds.MountAndBlade.dll",
  "TaleWorlds.ObjectSystem.dll"
)

Write-Host "Bannerwake Armor Archivist preflight"
Write-Host "Root:          $root"
Write-Host "BannerlordDir: $BannerlordDir"
Write-Host "Project:       $project"
Write-Host ""

$ok = $true
if (!(Test-Path $project)) { Write-Error "Project file not found."; $ok = $false }
if (!(Test-Path $bin)) { Write-Error "Bannerlord bin folder not found: $bin"; $ok = $false }
foreach ($dll in $needed) {
  $path = Join-Path $bin $dll
  if (Test-Path $path) { Write-Host "OK DLL: $dll" }
  else { Write-Error "Missing DLL: $path"; $ok = $false }
}

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if ($dotnet) { Write-Host "OK dotnet: $($dotnet.Source)" }
else { Write-Error "dotnet SDK not found. Install Visual Studio Build Tools or .NET SDK that can build net472 projects."; $ok = $false }

Write-Host ""
if ($ok) {
  Write-Host "Preflight paths look OK. Trying a build now..."
  dotnet build $project -c Release "/p:BannerlordDir=$BannerlordDir"
  if ($LASTEXITCODE -eq 0) {
    Write-Host "BUILD OK. You can run 02_BUILD_AND_INSTALL_CAPTURE_MOD.ps1 next."
  } else {
    Write-Warning "BUILD FAILED. Copy the errors and send them back. The Python scanner can still be used."
  }
} else {
  Write-Warning "Preflight failed. Fix the path/DLL/dotnet problems first."
}
