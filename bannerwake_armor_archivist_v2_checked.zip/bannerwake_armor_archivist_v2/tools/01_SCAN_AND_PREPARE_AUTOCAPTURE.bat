@echo off
setlocal
set MODULES=C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules
set WORKSHOP=C:\Program Files (x86)\Steam\steamapps\workshop\content\261550
set OUT=C:\BannerwakeArmorArchive
set CONFIG=%USERPROFILE%\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture

cd /d "%~dp0\.."
python bannerwake_armor_archivist.py scan --modules-root "%MODULES%" --modules-root "%WORKSHOP%" --out "%OUT%" --views front side back
if errorlevel 1 pause && exit /b 1

if not exist "%CONFIG%" mkdir "%CONFIG%"
python bannerwake_armor_archivist.py export-autocapture --queue "%OUT%\catalog\capture_queue.json" --out-tsv "%CONFIG%\capture_queue.tsv" --views front side back

copy /Y "config_templates\config.ini" "%CONFIG%\config.ini" >nul

echo.
echo DONE.
echo Queue:  %CONFIG%\capture_queue.tsv
echo Config: %CONFIG%\config.ini
echo Output: %OUT%\screenshots
echo.
pause
