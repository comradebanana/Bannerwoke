@echo off
setlocal
set MODULES=C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules
set WORKSHOP=C:\Program Files (x86)\Steam\steamapps\workshop\content\261550
set OUT=C:\BannerwakeArmorArchive
set SCREENSHOTS=C:\BannerwakeArmorArchive\screenshots

cd /d "%~dp0\.."
python bannerwake_armor_archivist.py scan ^
  --modules-root "%MODULES%" ^
  --modules-root "%WORKSHOP%" ^
  --screenshots-root "%SCREENSHOTS%" ^
  --out "%OUT%" ^
  --views front side back

if exist "%OUT%\gallery\armor_gallery.html" start "" "%OUT%\gallery\armor_gallery.html"
pause
