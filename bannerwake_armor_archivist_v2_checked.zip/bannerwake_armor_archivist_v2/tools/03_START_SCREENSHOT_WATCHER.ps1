param(
  [string]$SignalDir = "$env:USERPROFILE\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture\signal",
  [int]$PollMs = 100,
  [int]$StabilizeMs = 650,
  [switch]$ForegroundOnly
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$win32 = @"
using System;
using System.Runtime.InteropServices;
using System.Text;

public class BWWin32 {
  [StructLayout(LayoutKind.Sequential)]
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

  [DllImport("user32.dll")]
  public static extern IntPtr GetForegroundWindow();

  [DllImport("user32.dll")]
  public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

  [DllImport("user32.dll")]
  public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
}
"@
Add-Type $win32 -ErrorAction SilentlyContinue | Out-Null

function Read-ReadyFile([string]$path) {
  $map = @{}
  if (!(Test-Path $path)) { return $null }
  foreach ($line in Get-Content -LiteralPath $path -Encoding UTF8) {
    if ($line -match '^([^=]+)=(.*)$') {
      $map[$matches[1].Trim()] = $matches[2].Trim()
    }
  }
  return $map
}

function Get-BannerlordWindowHandle {
  if (-not $ForegroundOnly) {
    $proc = Get-Process | Where-Object {
      $_.MainWindowHandle -ne 0 -and ($_.ProcessName -like '*Bannerlord*' -or $_.MainWindowTitle -like '*Bannerlord*' -or $_.MainWindowTitle -like '*Mount & Blade*')
    } | Select-Object -First 1
    if ($proc) { return $proc.MainWindowHandle }
  }
  return [BWWin32]::GetForegroundWindow()
}

function Capture-Window([string]$outPath) {
  $hwnd = Get-BannerlordWindowHandle
  if ($hwnd -eq [IntPtr]::Zero) { throw "No usable window handle found. Put Bannerlord in the foreground." }

  $rect = New-Object BWWin32+RECT
  [void][BWWin32]::GetWindowRect($hwnd, [ref]$rect)
  $width = $rect.Right - $rect.Left
  $height = $rect.Bottom - $rect.Top
  if ($width -le 10 -or $height -le 10) { throw "Window rectangle is invalid: ${width}x${height}" }

  $dir = Split-Path -Parent $outPath
  if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

  $bmp = New-Object System.Drawing.Bitmap($width, $height)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  try {
    $g.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object System.Drawing.Size($width, $height)))
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
  }
  finally {
    $g.Dispose()
    $bmp.Dispose()
  }
}

if (!(Test-Path $SignalDir)) { New-Item -ItemType Directory -Path $SignalDir -Force | Out-Null }
$ready = Join-Path $SignalDir "ready.txt"
$ack = Join-Path $SignalDir "ack.txt"
$lastSeq = ""

Write-Host "Bannerwake Screenshot Watcher running."
Write-Host "SignalDir: $SignalDir"
Write-Host "Keep Bannerlord visible. Press Ctrl+C here to stop."

while ($true) {
  Start-Sleep -Milliseconds $PollMs
  if (!(Test-Path $ready)) { continue }

  $data = Read-ReadyFile $ready
  if ($null -eq $data) { continue }
  if ($data["status"] -ne "READY") { continue }

  $seq = $data["sequence"]
  if ([string]::IsNullOrWhiteSpace($seq) -or $seq -eq $lastSeq) { continue }

  $outPath = $data["output_path"]
  if ([string]::IsNullOrWhiteSpace($outPath)) { continue }

  Start-Sleep -Milliseconds $StabilizeMs
  try {
    Capture-Window $outPath
    $msg = "sequence=$seq`nstatus=DONE`noutput_path=$outPath`ntime=$(Get-Date -Format o)`n"
    Set-Content -LiteralPath $ack -Value $msg -Encoding UTF8
    $lastSeq = $seq
    Write-Host "Captured #$seq $($data['view']) $($data['item_id']) -> $outPath"
  }
  catch {
    $msg = "sequence=$seq`nstatus=ERROR`nerror=$($_.Exception.Message)`ntime=$(Get-Date -Format o)`n"
    Set-Content -LiteralPath $ack -Value $msg -Encoding UTF8
    $lastSeq = $seq
    Write-Warning "Capture failed #$seq: $($_.Exception.Message)"
  }
}
