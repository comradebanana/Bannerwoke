param(
  [string]$BannerlordDir = "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\BannerwakeArmorAutoCapture")).Path
)

$ErrorActionPreference = "Stop"
$moduleId = "BannerwakeArmorAutoCapture"
$project = Join-Path $ProjectRoot "Source\BannerwakeArmorAutoCapture\BannerwakeArmorAutoCapture.csproj"
$gameModuleDir = Join-Path $BannerlordDir "Modules\$moduleId"

Write-Host "Building Bannerwake Armor AutoCapture..."
Write-Host "BannerlordDir: $BannerlordDir"
Write-Host "ProjectRoot:   $ProjectRoot"

dotnet build $project -c Release "/p:BannerlordDir=$BannerlordDir"

if (!(Test-Path $gameModuleDir)) { New-Item -ItemType Directory -Path $gameModuleDir -Force | Out-Null }
Copy-Item -Path (Join-Path $ProjectRoot "SubModule.xml") -Destination (Join-Path $gameModuleDir "SubModule.xml") -Force
if (Test-Path (Join-Path $ProjectRoot "ModuleData")) {
  Copy-Item -Path (Join-Path $ProjectRoot "ModuleData") -Destination $gameModuleDir -Recurse -Force
}
if (!(Test-Path (Join-Path $gameModuleDir "bin\Win64_Shipping_Client"))) {
  New-Item -ItemType Directory -Path (Join-Path $gameModuleDir "bin\Win64_Shipping_Client") -Force | Out-Null
}
Copy-Item -Path (Join-Path $ProjectRoot "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.dll") -Destination (Join-Path $gameModuleDir "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.dll") -Force
if (Test-Path (Join-Path $ProjectRoot "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.pdb")) {
  Copy-Item -Path (Join-Path $ProjectRoot "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.pdb") -Destination (Join-Path $gameModuleDir "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.pdb") -Force
}

Write-Host "Installed to: $gameModuleDir"
Write-Host "Enable Bannerwake Armor AutoCapture in the Bannerlord launcher."
