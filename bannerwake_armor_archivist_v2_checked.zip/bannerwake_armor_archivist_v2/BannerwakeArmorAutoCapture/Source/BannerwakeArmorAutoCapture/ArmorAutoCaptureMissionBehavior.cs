using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using TaleWorlds.Core;
using TaleWorlds.InputSystem;
using TaleWorlds.Library;
using TaleWorlds.MountAndBlade;
using TaleWorlds.ObjectSystem;

namespace BannerwakeArmorAutoCapture
{
    public sealed class ArmorAutoCaptureMissionBehavior : MissionBehavior
    {
        private readonly List<CaptureItem> _queue = new List<CaptureItem>();
        private readonly List<string> _views = new List<string>();
        private readonly List<Agent> _spawnedAgents = new List<Agent>();

        private CaptureConfig _config;
        private bool _hintShown;
        private bool _running;
        private bool _waitingForAck;
        private bool _queueLoaded;
        private int _index;
        private int _viewIndex;
        private int _sequence;
        private float _nextActionAt;
        private float _missionTime;
        private string _lastReadyText = string.Empty;

        public override MissionBehaviorType BehaviorType => MissionBehaviorType.Other;

        public override void OnMissionTick(float dt)
        {
            base.OnMissionTick(dt);
            _missionTime += dt;

            if (!_hintShown && Mission?.MainAgent != null)
            {
                _hintShown = true;
                LoadEverything(showMessage: true);
                InformationManager.DisplayMessage(new InformationMessage(
                    "Bannerwake AutoCapture: Ctrl+F12 reload, Ctrl+F10 one shot, Ctrl+F9 start/stop, Ctrl+F11 clear."));
            }

            if (Input.IsKeyDown(InputKey.LeftControl) && Input.IsKeyPressed(InputKey.F12))
            {
                LoadEverything(showMessage: true);
            }

            if (Input.IsKeyDown(InputKey.LeftControl) && Input.IsKeyPressed(InputKey.F11))
            {
                ClearPreviewAgents(true);
            }

            if (Input.IsKeyDown(InputKey.LeftControl) && Input.IsKeyPressed(InputKey.F10))
            {
                if (!_queueLoaded)
                {
                    LoadEverything(showMessage: true);
                }
                CaptureCurrentOrNext(manual: true);
            }

            if (Input.IsKeyDown(InputKey.LeftControl) && Input.IsKeyPressed(InputKey.F9))
            {
                ToggleRun();
            }

            if (!_running)
            {
                return;
            }

            float now = _missionTime;
            if (now < _nextActionAt)
            {
                return;
            }

            if (_waitingForAck)
            {
                if (AckExists())
                {
                    ConsumeAckAndAdvance();
                    _nextActionAt = now + _config.BetweenShotsSeconds;
                }
                return;
            }

            CaptureCurrentOrNext(manual: false);
        }

        public override void OnMissionStateFinalized()
        {
            _spawnedAgents.Clear();
            base.OnMissionStateFinalized();
        }

        private void LoadEverything(bool showMessage)
        {
            _config = CaptureConfig.Load();
            EnsureDirectories();
            LoadQueue(showMessage);
            LoadViews();
        }

        private void LoadViews()
        {
            _views.Clear();
            foreach (string view in (_config.Views ?? "front").Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string v = view.Trim().ToLowerInvariant();
                if (v == "front" || v == "side" || v == "back" || v == "detail")
                {
                    _views.Add(v);
                }
            }
            if (_views.Count == 0)
            {
                _views.Add("front");
            }
        }

        private void LoadQueue(bool showMessage)
        {
            _queue.Clear();
            _queueLoaded = false;

            if (!File.Exists(_config.CaptureQueuePath))
            {
                if (showMessage)
                {
                    InformationManager.DisplayMessage(new InformationMessage(
                        "Bannerwake AutoCapture: queue not found: " + _config.CaptureQueuePath));
                }
                return;
            }

            string[] lines = File.ReadAllLines(_config.CaptureQueuePath);
            for (int i = 1; i < lines.Length; i++)
            {
                CaptureItem item = CaptureItem.FromTsv(lines[i]);
                if (item == null || string.IsNullOrWhiteSpace(item.ItemId))
                {
                    continue;
                }
                if (!IsSlotSupported(item.Slot))
                {
                    continue;
                }
                _queue.Add(item);
            }

            _queueLoaded = _queue.Count > 0;
            _index = Math.Max(0, Math.Min(_config.StartIndex - 1, Math.Max(0, _queue.Count - 1)));
            _viewIndex = 0;

            if (showMessage)
            {
                InformationManager.DisplayMessage(new InformationMessage(
                    "Bannerwake AutoCapture: loaded " + _queue.Count + " items. Start index " + (_index + 1) + "."));
            }
        }

        private void ToggleRun()
        {
            if (!_queueLoaded)
            {
                LoadEverything(showMessage: true);
            }

            _running = !_running;
            _waitingForAck = false;
            _nextActionAt = _missionTime + 0.1f;
            InformationManager.DisplayMessage(new InformationMessage(
                _running ? "Bannerwake AutoCapture: RUNNING." : "Bannerwake AutoCapture: STOPPED."));
        }

        private void CaptureCurrentOrNext(bool manual)
        {
            if (!_queueLoaded || _queue.Count == 0)
            {
                InformationManager.DisplayMessage(new InformationMessage("Bannerwake AutoCapture: no queue loaded."));
                _running = false;
                return;
            }

            if (_index >= _queue.Count)
            {
                _running = false;
                InformationManager.DisplayMessage(new InformationMessage("Bannerwake AutoCapture: finished queue."));
                return;
            }

            CaptureItem item = _queue[_index];
            string view = _views[Math.Max(0, Math.Min(_viewIndex, _views.Count - 1))];
            bool spawned = SpawnPreviewAgent(item, view);
            if (!spawned)
            {
                AdvanceCursor();
                return;
            }

            _sequence++;
            WriteReadySignal(item, view, _sequence);
            _waitingForAck = !manual || _config.WaitForWatcherAck;
            _nextActionAt = _missionTime + _config.DelayAfterSpawnSeconds;

            // Do NOT show a per-item on-screen message here. The external watcher captures
            // the Bannerlord window, so UI notifications would appear inside armor screenshots.
            // Progress is printed by the watcher console instead.

            if (manual && !_config.WaitForWatcherAck)
            {
                AdvanceCursor();
            }
        }

        private bool SpawnPreviewAgent(CaptureItem item, string view)
        {
            Agent mainAgent = Mission?.MainAgent;
            if (mainAgent == null || !mainAgent.IsActive())
            {
                InformationManager.DisplayMessage(new InformationMessage("Bannerwake AutoCapture: enter a mission scene first."));
                return false;
            }

            CharacterObject character = GetBaseCharacter();
            if (character == null)
            {
                InformationManager.DisplayMessage(new InformationMessage("Bannerwake AutoCapture: base troop not found."));
                return false;
            }

            ItemObject itemObject = MBObjectManager.Instance.GetObject<ItemObject>(item.ItemId);
            if (itemObject == null)
            {
                WriteSkipSignal(item, view, "ItemObject not found");
                return false;
            }

            ClearPreviewAgents(false);
            Equipment equipment = BuildEquipment(character, itemObject, item.Slot);

            Vec3 forward = mainAgent.LookDirection;
            forward.z = 0f;
            if (!forward.IsNonZero)
            {
                forward = Vec3.Forward;
            }
            forward.Normalize();

            Vec3 side = new Vec3(-forward.y, forward.x, 0f, 0f);
            Vec2 facePlayer = new Vec2(-forward.x, -forward.y);
            facePlayer.Normalize();
            Vec2 direction = DirectionForView(facePlayer, view);

            Vec3 position = new Vec3(
                mainAgent.Position.x + (forward.x * _config.ForwardOffset) + (side.x * _config.SideOffset),
                mainAgent.Position.y + (forward.y * _config.ForwardOffset) + (side.y * _config.SideOffset),
                mainAgent.Position.z,
                mainAgent.Position.w);

            Team team = mainAgent.Team ?? Mission.PlayerTeam ?? Mission.DefenderTeam ?? Mission.AttackerTeam;
            AgentBuildData buildData = new AgentBuildData(character)
                .Team(team)
                .InitialPosition(in position)
                .InitialDirection(in direction)
                .Equipment(equipment)
                .FixedEquipment(true)
                .NoHorses(true)
                .Controller(AgentControllerType.AI)
                .CanSpawnOutsideOfMissionBoundary(true);

            Agent spawnedAgent = Mission.SpawnAgent(buildData, false);
            if (spawnedAgent == null)
            {
                WriteSkipSignal(item, view, "SpawnAgent returned null");
                return false;
            }

            spawnedAgent.SetIsAIPaused(true);
            spawnedAgent.SetMaximumSpeedLimit(0f, true);
            spawnedAgent.SetMortalityState(Agent.MortalityState.Invulnerable);
            _spawnedAgents.Add(spawnedAgent);
            return true;
        }

        private CharacterObject GetBaseCharacter()
        {
            string[] ids = new[]
            {
                _config.BaseTroopId,
                "imperial_recruit",
                "sturgian_recruit",
                "vlandian_recruit",
                "battanian_volunteer",
                "aserai_recruit",
                "khuzait_nomad"
            };

            foreach (string id in ids)
            {
                if (string.IsNullOrWhiteSpace(id))
                {
                    continue;
                }
                CharacterObject character = MBObjectManager.Instance.GetObject<CharacterObject>(id.Trim());
                if (character != null)
                {
                    return character;
                }
            }
            return null;
        }

        private static Equipment BuildEquipment(CharacterObject character, ItemObject item, string slot)
        {
            Equipment source = character.FirstBattleEquipment ?? character.Equipment;
            Equipment equipment = source != null
                ? new Equipment(source)
                : new Equipment(Equipment.EquipmentType.Battle);

            string normalizedSlot = Normalize(slot);

            if (normalizedSlot == "bodyarmor")
            {
                ClearArmorSlots(equipment);
                equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Body, new EquipmentElement(item));
                return equipment;
            }

            if (normalizedSlot == "headarmor")
            {
                equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Head, new EquipmentElement(item));
                equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Cape, default(EquipmentElement));
                return equipment;
            }

            if (normalizedSlot == "cape" || normalizedSlot == "shoulder")
            {
                equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Cape, new EquipmentElement(item));
                return equipment;
            }

            if (normalizedSlot == "handarmor")
            {
                equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Gloves, new EquipmentElement(item));
                return equipment;
            }

            if (normalizedSlot == "legarmor")
            {
                equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Leg, new EquipmentElement(item));
                return equipment;
            }

            if (normalizedSlot == "shield")
            {
                ClearWeaponSlots(equipment);
                equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon0, new EquipmentElement(item));
                return equipment;
            }

            return equipment;
        }

        private static void ClearArmorSlots(Equipment equipment)
        {
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Head, default(EquipmentElement));
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Body, default(EquipmentElement));
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Cape, default(EquipmentElement));
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Gloves, default(EquipmentElement));
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Leg, default(EquipmentElement));
        }

        private static void ClearWeaponSlots(Equipment equipment)
        {
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon0, default(EquipmentElement));
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon1, default(EquipmentElement));
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon2, default(EquipmentElement));
            equipment.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon3, default(EquipmentElement));
        }

        private static Vec2 DirectionForView(Vec2 facePlayer, string view)
        {
            if (view == "side")
            {
                return Rotate(facePlayer, 90f);
            }
            if (view == "back")
            {
                return Rotate(facePlayer, 180f);
            }
            return facePlayer;
        }

        private static Vec2 Rotate(Vec2 v, float degrees)
        {
            double radians = degrees * Math.PI / 180.0;
            float cos = (float)Math.Cos(radians);
            float sin = (float)Math.Sin(radians);
            Vec2 result = new Vec2((v.x * cos) - (v.y * sin), (v.x * sin) + (v.y * cos));
            result.Normalize();
            return result;
        }

        private void WriteReadySignal(CaptureItem item, string view, int sequence)
        {
            string outputPath = BuildOutputPath(item, view);
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            SafeDelete(_config.AckPath);

            string text =
                "sequence=" + sequence + Environment.NewLine +
                "item_id=" + item.ItemId + Environment.NewLine +
                "slot=" + item.Slot + Environment.NewLine +
                "view=" + view + Environment.NewLine +
                "order=" + item.Order + Environment.NewLine +
                "output_path=" + outputPath + Environment.NewLine +
                "display_name=" + item.DisplayName + Environment.NewLine +
                "source_module=" + item.SourceModule + Environment.NewLine +
                "status=READY" + Environment.NewLine;

            File.WriteAllText(_config.ReadyPath, text);
            _lastReadyText = text;
        }

        private void WriteSkipSignal(CaptureItem item, string view, string reason)
        {
            EnsureDirectories();
            string text =
                "sequence=" + (++_sequence) + Environment.NewLine +
                "item_id=" + item.ItemId + Environment.NewLine +
                "slot=" + item.Slot + Environment.NewLine +
                "view=" + view + Environment.NewLine +
                "order=" + item.Order + Environment.NewLine +
                "status=SKIPPED" + Environment.NewLine +
                "reason=" + reason + Environment.NewLine;
            File.WriteAllText(_config.ReadyPath, text);
        }

        private string BuildOutputPath(CaptureItem item, string view)
        {
            string filename = item.GetFilename(view);
            if (string.IsNullOrWhiteSpace(filename))
            {
                string slot = Normalize(item.Slot);
                filename = slot + "__" + item.ItemId + "__" + view + ".png";
            }
            string viewFolder = _config.GroupByView ? view : "all";
            return Path.Combine(_config.OutputRoot, viewFolder, filename);
        }

        private bool AckExists()
        {
            return File.Exists(_config.AckPath);
        }

        private void ConsumeAckAndAdvance()
        {
            try
            {
                SafeDelete(_config.AckPath);
            }
            catch
            {
            }
            _waitingForAck = false;
            AdvanceCursor();
        }

        private void AdvanceCursor()
        {
            _viewIndex++;
            if (_viewIndex >= _views.Count)
            {
                _viewIndex = 0;
                _index++;
            }
        }

        private void ClearPreviewAgents(bool showMessage)
        {
            int cleared = 0;
            foreach (Agent agent in _spawnedAgents)
            {
                if (agent != null && agent.IsActive())
                {
                    agent.FadeOut(true, false);
                    cleared++;
                }
            }
            _spawnedAgents.Clear();
            if (showMessage)
            {
                InformationManager.DisplayMessage(new InformationMessage("Bannerwake AutoCapture: cleared " + cleared + " agent(s)."));
            }
        }

        private void EnsureDirectories()
        {
            Directory.CreateDirectory(_config.ConfigRoot);
            Directory.CreateDirectory(_config.SignalDir);
            Directory.CreateDirectory(_config.OutputRoot);
        }

        private static bool IsSlotSupported(string slot)
        {
            string s = Normalize(slot);
            return s == "bodyarmor" || s == "headarmor" || s == "cape" || s == "shoulder" ||
                   s == "handarmor" || s == "legarmor" || s == "shield";
        }

        private static string Normalize(string value)
        {
            if (value == null)
            {
                return string.Empty;
            }
            char[] arr = value.ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray();
            return new string(arr);
        }

        private static void SafeDelete(string path)
        {
            if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
            {
                File.Delete(path);
            }
        }

        private sealed class CaptureItem
        {
            public int Order;
            public string ItemId;
            public string Slot;
            public string FilenameFront;
            public string FilenameSide;
            public string FilenameBack;
            public string FilenameDetail;
            public string DisplayName;
            public string SourceModule;

            public string GetFilename(string view)
            {
                if (view == "front") return FilenameFront;
                if (view == "side") return FilenameSide;
                if (view == "back") return FilenameBack;
                if (view == "detail") return FilenameDetail;
                return FilenameFront;
            }

            public static CaptureItem FromTsv(string line)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    return null;
                }

                string[] parts = line.Split('\t');
                if (parts.Length < 3)
                {
                    return null;
                }

                int order = 0;
                int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out order);
                return new CaptureItem
                {
                    Order = order,
                    ItemId = Get(parts, 1),
                    Slot = Get(parts, 2),
                    FilenameFront = Get(parts, 3),
                    FilenameSide = Get(parts, 4),
                    FilenameBack = Get(parts, 5),
                    FilenameDetail = Get(parts, 6),
                    DisplayName = Get(parts, 7),
                    SourceModule = Get(parts, 8),
                };
            }

            private static string Get(string[] parts, int index)
            {
                return index >= 0 && index < parts.Length ? parts[index] : string.Empty;
            }
        }

        private sealed class CaptureConfig
        {
            public string ConfigRoot;
            public string SignalDir;
            public string CaptureQueuePath;
            public string OutputRoot;
            public string ReadyPath;
            public string AckPath;
            public string Views;
            public string BaseTroopId;
            public int StartIndex;
            public bool GroupByView;
            public bool WaitForWatcherAck;
            public float DelayAfterSpawnSeconds;
            public float BetweenShotsSeconds;
            public float ForwardOffset;
            public float SideOffset;

            public static CaptureConfig Load()
            {
                string documents = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string root = Path.Combine(documents, "Mount and Blade II Bannerlord", "Configs", "BannerwakeArmorAutoCapture");
                string iniPath = Path.Combine(root, "config.ini");

                CaptureConfig cfg = new CaptureConfig
                {
                    ConfigRoot = root,
                    SignalDir = Path.Combine(root, "signal"),
                    CaptureQueuePath = Path.Combine(root, "capture_queue.tsv"),
                    OutputRoot = @"C:\BannerwakeArmorArchive\screenshots",
                    Views = "front",
                    BaseTroopId = "imperial_recruit",
                    StartIndex = 1,
                    GroupByView = true,
                    WaitForWatcherAck = true,
                    DelayAfterSpawnSeconds = 0.75f,
                    BetweenShotsSeconds = 0.15f,
                    ForwardOffset = 5.0f,
                    SideOffset = 0.0f,
                };

                if (File.Exists(iniPath))
                {
                    foreach (string raw in File.ReadAllLines(iniPath))
                    {
                        string line = raw.Trim();
                        if (line.Length == 0 || line.StartsWith("#") || !line.Contains("="))
                        {
                            continue;
                        }
                        string[] pair = line.Split(new[] { '=' }, 2);
                        string key = pair[0].Trim().ToLowerInvariant();
                        string value = pair[1].Trim();
                        cfg.Apply(key, value);
                    }
                }

                cfg.ReadyPath = Path.Combine(cfg.SignalDir, "ready.txt");
                cfg.AckPath = Path.Combine(cfg.SignalDir, "ack.txt");
                return cfg;
            }

            private void Apply(string key, string value)
            {
                if (key == "capturequeuepath") CaptureQueuePath = Expand(value);
                else if (key == "outputroot") OutputRoot = Expand(value);
                else if (key == "views") Views = value;
                else if (key == "basetroopid") BaseTroopId = value;
                else if (key == "startindex") StartIndex = ParseInt(value, StartIndex);
                else if (key == "groupbyview") GroupByView = ParseBool(value, GroupByView);
                else if (key == "waitforwatcherack") WaitForWatcherAck = ParseBool(value, WaitForWatcherAck);
                else if (key == "delayafterspawnseconds") DelayAfterSpawnSeconds = ParseFloat(value, DelayAfterSpawnSeconds);
                else if (key == "betweenshotsseconds") BetweenShotsSeconds = ParseFloat(value, BetweenShotsSeconds);
                else if (key == "forwardoffset") ForwardOffset = ParseFloat(value, ForwardOffset);
                else if (key == "sideoffset") SideOffset = ParseFloat(value, SideOffset);
            }

            private static string Expand(string value)
            {
                return Environment.ExpandEnvironmentVariables(value);
            }

            private static int ParseInt(string value, int fallback)
            {
                int parsed;
                return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed) ? parsed : fallback;
            }

            private static float ParseFloat(string value, float fallback)
            {
                float parsed;
                return float.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out parsed) ? parsed : fallback;
            }

            private static bool ParseBool(string value, bool fallback)
            {
                if (string.Equals(value, "true", StringComparison.OrdinalIgnoreCase) || value == "1" || string.Equals(value, "yes", StringComparison.OrdinalIgnoreCase)) return true;
                if (string.Equals(value, "false", StringComparison.OrdinalIgnoreCase) || value == "0" || string.Equals(value, "no", StringComparison.OrdinalIgnoreCase)) return false;
                return fallback;
            }
        }
    }
}
