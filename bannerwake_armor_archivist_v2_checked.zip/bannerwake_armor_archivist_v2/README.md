# Bannerwake Armor Archivist

This package contains a Windows-friendly external tool for documenting Bannerlord armor **as data and visuals**.

Main file:

```text
bannerwake_armor_archivist.py
```

Run this first to generate helper files:

```powershell
python .\bannerwake_armor_archivist.py init --out .
```

Then edit the generated `RUN_BANNERWAKE_ARMOR_SCAN.bat` paths and run it.

## What it creates

- `armor_catalog.csv` — best file for Claude/Codex
- `armor_catalog.json` — structured data for tools
- `capture_queue.json` — ordered screenshot capture list
- `armor_gallery.html` — local visual gallery
- `recolor_candidates.md` — likely `bw_` texture/material candidates
- `armor_missing_screenshots.md` — items still needing screenshots

## Workflow

1. Scan XML to build catalogue.
2. Use Modding Kit / Item Viewer / your screenshotter to capture armor in the same order as `capture_queue.json`.
3. Use `link-screenshots` to rename/copy raw screenshots to item IDs.
4. Rerun scan with `--screenshots-root`.
5. Open `gallery/armor_gallery.html`.

## Important

The tool does **not** require Bannerlord DLLs and does **not** modify your game. It only reads XML and links screenshots.
