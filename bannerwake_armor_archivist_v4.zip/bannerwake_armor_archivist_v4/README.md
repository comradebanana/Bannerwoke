# Bannerwake Armor Archivist v4

Automated visual + data armor archive builder for Mount & Blade II: Bannerlord / Bannerwake.

It has three parts:

1. **Python scanner** — reads Bannerlord/mod XML and creates CSV/JSON/reports/gallery.
2. **Bannerlord in-game capture module** — equips one armor item at a time on a mannequin and signals when ready.
3. **PowerShell screenshot watcher** — captures the Bannerlord window and saves screenshots with the correct item ID filename.

Read this first:

```txt
FULL_COMMANDS_FROM_ZERO.md
```

## Important status

- Python/data/gallery side: tested with mock modules in this environment.
- C# Bannerlord module: must be compiled on your PC against your local Bannerlord DLLs.
- Required before install:

```powershell
.\tools\00_PREFLIGHT_CHECK.ps1
```

Only continue if it says `BUILD OK`.

## Default first pass

The default batch file is **front-only**. This is intentional.

Do not waste time capturing front/side/back for every trash asset. First create a full front gallery, then pick useful Bannerwake candidates for side/back.

## Main outputs

```txt
C:\BannerwakeArmorArchive\catalog\armor_catalog.csv
C:\BannerwakeArmorArchive\catalog\armor_catalog.json
C:\BannerwakeArmorArchive\reports\recolor_candidates.md
C:\BannerwakeArmorArchive\gallery\armor_gallery.html
C:\BannerwakeArmorArchive\screenshots\
```

## v4 fixes

See:

```txt
V4_TEST_REPORT.md
```
