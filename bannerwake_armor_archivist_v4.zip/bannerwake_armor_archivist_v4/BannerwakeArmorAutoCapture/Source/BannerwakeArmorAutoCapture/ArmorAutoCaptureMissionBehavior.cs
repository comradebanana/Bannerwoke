using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using TaleWorlds.Core;
using TaleWorlds.InputSystem;
using TaleWorlds.Library;
using TaleWorlds.MountAndBlade;
using TaleWorlds.ObjectSystem;

namespace BannerwakeArmorAutoCapture
{
    /// <summary>
    /// Bannerwake Armor AutoCapture — Mission behavior (v4 hardened).
    ///
    /// Key improvements over v2:
    ///   - Armor render delay: waits 1.0 s after spawn before writing the ready signal.
    ///     This gives the game engine time to finish streaming the mesh/texture. The
    ///     original v2 used 0.75 s which was too short on many machines under DX12.
    ///   - DelayAfterSpawnSeconds is configurable (default 1.0 s) and documented.
    ///   - Between-shots cooldown raised to 0.25 s so the signal handshake never races.
    ///   - ClearPreviewAgents now fades ALL spawned agents, not just the last one.
    ///   - BuildEquipment properly strips the entire outfit before equipping a
    ///     BodyArmor item so the mannequin shows ONLY that piece (no visual bleed).
    ///   - HorseHarness / HorseArmor are catalogued by Python but skipped by human mannequin capture.
    ///   - GetBaseCharacter uses CharacterObject.All as a safe fallback if the
    ///     explicit IDs don't resolve (NavalDLC recruit IDs differ from vanilla).
    ///   - SetMortalityState replaced with SetMortalityState(Agent.MortalityState.Invulnerable)
    ///     guarded by a null-check so it compiles cleanly on v1.4.5.
    ///   - Config keys are lower-cased on read to avoid case-sensitivity bugs.
    ///   - TSV parser skips lines starting with '#' (comment lines written by Python tool).
    ///   - ToggleRun prints item count and current start index on HUD so the user
    ///     can confirm the queue loaded correctly before the run begins.
    ///   - WriteReadySignal deletes ready.txt then ack.txt in that order before writing
    ///     the new signal to prevent the watcher from processing a stale signal.
    ///   - All file I/O wrapped in try/catch with error display; a single file error
    ///     no longer crashes the entire capture run.
    /// </summary>
    public sealed class ArmorAutoCaptureMissionBehavior : MissionBehavior
    {
        // ------------------------------------------------------------------ state

        private readonly List<CaptureItem> _queue = new List<CaptureItem>();
        private readonly List<string> _views = new List<string>();
        private readonly List<Agent> _spawnedAgents = new List<Agent>();

        private CaptureConfig _config;
        private bool _hintShown;
        private bool _running;
        private bool _singleShotMode;
        private bool _waitingForAck;
        private bool _queueLoaded;
        private int _index;
        private int _viewIndex;
        private int _sequence;

        // _readyAt is the mission time at which we should write the ready signal
        // (i.e., after the armor render delay has elapsed).
        private float _readyAt = -1f;
        private float _nextActionAt = 0f;
        private float _missionTime = 0f;

        public override MissionBehaviorType BehaviorType => MissionBehaviorType.Other;

        // ------------------------------------------------------------------ tick

        public override void OnMissionTick(float dt)
        {
            base.OnMissionTick(dt);
            _missionTime += dt;

            // One-time initialise + HUD hint
            if (!_hintShown && Mission?.MainAgent != null)
            {
                _hintShown = true;
                LoadEverything(showMessage: true);
                HUD("Ctrl+F9 start/stop | Ctrl+F10 single shot | Ctrl+F11 clear | Ctrl+F12 reload queue");
            }

            // Hotkeys
            if (KeyCombo(InputKey.F12)) LoadEverything(showMessage: true);
            if (KeyCombo(InputKey.F11)) ClearPreviewAgents(announce: true);
            if (KeyCombo(InputKey.F10)) SingleShot();
            if (KeyCombo(InputKey.F9))  ToggleRun();

            if (!_running) return;

            float now = _missionTime;

            // Phase 1: waiting for the armor-render delay to elapse, then signal
            if (_readyAt >= 0f)
            {
                if (now >= _readyAt)
                {
                    // Armor should be fully rendered now — write the ready signal
                    if (_queue.Count > 0 && _index < _queue.Count)
                    {
                        CaptureItem item = _queue[_index];
                        string view = SafeView();
                        WriteReadySignal(item, view, ++_sequence);
                        if (_config.WaitForWatcherAck)
                        {
                            _waitingForAck = true;
                        }
                        else
                        {
                            _waitingForAck = false;
                            AdvanceCursor();
                            StopIfSingleShot();
                            _nextActionAt = _missionTime + _config.BetweenShotsSeconds;
                        }
                    }
                    _readyAt = -1f;
                }
                return;
            }

            // Phase 2: waiting for watcher ack
            if (_waitingForAck)
            {
                if (AckExists())
                {
                    string ackStatus = ReadAckStatus();
                    if (ackStatus.Equals("ERROR", StringComparison.OrdinalIgnoreCase))
                    {
                        _running = false;
                        _waitingForAck = false;
                        HUD("Watcher reported screenshot ERROR. Capture stopped at item #" + (_index + 1) + ". Fix watcher/window and press Ctrl+F9 again.");
                        return;
                    }

                    ConsumeAckAndAdvance();
                    _nextActionAt = now + _config.BetweenShotsSeconds;
                }
                return;
            }

            // Phase 3: waiting between shots
            if (now < _nextActionAt) return;

            // Phase 4: spawn the next item
            SpawnAndScheduleSignal();
        }

        public override void OnMissionStateFinalized()
        {
            _spawnedAgents.Clear();
            base.OnMissionStateFinalized();
        }

        // ------------------------------------------------------------------ helpers

        private bool KeyCombo(InputKey key)
        {
            return Input.IsKeyDown(InputKey.LeftControl) && Input.IsKeyPressed(key);
        }

        private string SafeView()
        {
            int vi = Math.Max(0, Math.Min(_viewIndex, _views.Count - 1));
            return _views.Count > 0 ? _views[vi] : "front";
        }

        private void HUD(string msg)
        {
            InformationManager.DisplayMessage(new InformationMessage("[BW] " + msg));
        }

        // ------------------------------------------------------------------ load

        private void LoadEverything(bool showMessage)
        {
            _config = CaptureConfig.Load();
            EnsureDirectories();
            LoadViews();
            LoadQueue(showMessage);
        }

        private void LoadViews()
        {
            _views.Clear();
            string raw = _config.Views ?? "front";
            foreach (string token in raw.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string v = token.Trim().ToLowerInvariant();
                if (v == "front" || v == "side" || v == "back" || v == "detail")
                    _views.Add(v);
            }
            if (_views.Count == 0) _views.Add("front");
        }

        private void LoadQueue(bool showMessage)
        {
            _queue.Clear();
            _queueLoaded = false;

            if (!File.Exists(_config.CaptureQueuePath))
            {
                if (showMessage)
                    HUD("Queue not found: " + _config.CaptureQueuePath);
                return;
            }

            string[] lines;
            try { lines = File.ReadAllLines(_config.CaptureQueuePath); }
            catch (Exception ex)
            {
                HUD("Queue read error: " + ex.Message);
                return;
            }

            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue; // skip comments
                CaptureItem item = CaptureItem.FromTsv(line);
                if (item == null || string.IsNullOrWhiteSpace(item.ItemId)) continue;
                if (line == lines[0] && item.ItemId == "item_id") continue; // header row
                if (!IsSlotSupported(item.Slot)) continue;
                _queue.Add(item);
            }

            _queueLoaded = _queue.Count > 0;
            int startIdx = Math.Max(1, _config.StartIndex);
            _index = Math.Max(0, Math.Min(startIdx - 1, Math.Max(0, _queue.Count - 1)));
            _viewIndex = 0;

            if (showMessage)
                HUD($"Queue: {_queue.Count} items. Starting at #{_index + 1}. Views: {string.Join(",", _views)}");
        }

        // ------------------------------------------------------------------ run control

        private void ToggleRun()
        {
            if (!_queueLoaded) LoadEverything(showMessage: true);
            _running = !_running;
            _singleShotMode = false;
            _waitingForAck = false;
            _readyAt = -1f;
            _nextActionAt = _missionTime + 0.1f;
            HUD(_running
                ? $"RUNNING — {_queue.Count - _index} items remaining. Render delay: {_config.DelayAfterSpawnSeconds:0.00}s"
                : "STOPPED.");
        }

        private void SingleShot()
        {
            if (!_queueLoaded) LoadEverything(showMessage: true);
            if (!_queueLoaded || _queue.Count == 0) { HUD("No queue loaded."); return; }

            // v4 fix: in v3 Ctrl+F10 spawned the mannequin but never wrote ready.txt,
            // because OnMissionTick returned early when _running was false.
            // Single-shot now runs the normal ready/ack pipeline once, then stops.
            _singleShotMode = true;
            _running = true;
            _waitingForAck = false;
            _readyAt = -1f;
            _nextActionAt = _missionTime;
            SpawnAndScheduleSignal();
            HUD("Single-shot scheduled for item #" + (_index + 1) + " view " + SafeView());
        }

        // ------------------------------------------------------------------ spawn + signal

        /// <summary>
        /// Spawns the agent for the current item/view, then schedules the ready signal
        /// after DelayAfterSpawnSeconds to allow armor meshes to stream in.
        /// </summary>
        private void SpawnAndScheduleSignal()
        {
            if (!_queueLoaded || _queue.Count == 0)
            {
                HUD("No queue.");
                _running = false;
                return;
            }

            if (_index >= _queue.Count)
            {
                _running = false;
                HUD("Queue complete.");
                return;
            }

            CaptureItem item = _queue[_index];
            string view = SafeView();

            bool ok = SpawnPreviewAgent(item, view);
            if (!ok)
            {
                WriteSkipSignal(item, view, "spawn failed");
                AdvanceCursor();
                StopIfSingleShot();
                _nextActionAt = _missionTime + _config.BetweenShotsSeconds;
                return;
            }

            // Schedule ready signal after render delay (default 1.0 s)
            _readyAt = _missionTime + _config.DelayAfterSpawnSeconds;
        }

        private bool SpawnPreviewAgent(CaptureItem item, string view)
        {
            Agent mainAgent = Mission?.MainAgent;
            if (mainAgent == null || !mainAgent.IsActive())
            {
                HUD("Enter a mission scene first.");
                return false;
            }

            CharacterObject character = GetBaseCharacter();
            if (character == null)
            {
                HUD("Base troop not found. Check BaseTroopId in config.ini.");
                return false;
            }

            ItemObject itemObject = MBObjectManager.Instance.GetObject<ItemObject>(item.ItemId);
            if (itemObject == null)
            {
                // Item ID not registered — skip silently (common for unreleased/filtered items)
                return false;
            }

            ClearPreviewAgents(announce: false);

            Equipment equipment = BuildEquipment(character, itemObject, item.Slot);

            // Position mannequin in front of player
            Vec3 fwd = mainAgent.LookDirection;
            fwd.z = 0f;
            if (!fwd.IsNonZero) fwd = Vec3.Forward;
            fwd.Normalize();

            Vec3 right = new Vec3(-fwd.y, fwd.x, 0f, 0f);
            Vec2 facingPlayer = new Vec2(-fwd.x, -fwd.y);
            facingPlayer.Normalize();
            Vec2 direction = DirectionForView(facingPlayer, view);

            Vec3 position = new Vec3(
                mainAgent.Position.x + fwd.x * _config.ForwardOffset + right.x * _config.SideOffset,
                mainAgent.Position.y + fwd.y * _config.ForwardOffset + right.y * _config.SideOffset,
                mainAgent.Position.z,
                mainAgent.Position.w);

            Team team = mainAgent.Team
                ?? Mission?.PlayerTeam
                ?? Mission?.DefenderTeam
                ?? Mission?.AttackerTeam;

            AgentBuildData buildData = new AgentBuildData(character)
                .Team(team)
                .InitialPosition(in position)
                .InitialDirection(in direction)
                .Equipment(equipment)
                .FixedEquipment(true)
                .NoHorses(true)
                .Controller(AgentControllerType.AI)
                .CanSpawnOutsideOfMissionBoundary(true);

            Agent spawned = null;
            try { spawned = Mission.SpawnAgent(buildData, false); }
            catch (Exception ex)
            {
                HUD("SpawnAgent threw: " + ex.Message);
                return false;
            }

            if (spawned == null) return false;

            // Freeze the mannequin
            try { spawned.SetIsAIPaused(true); } catch { /* non-fatal */ }
            try { spawned.SetMaximumSpeedLimit(0f, true); } catch { /* non-fatal */ }
            try { spawned.SetMortalityState(Agent.MortalityState.Invulnerable); } catch { /* non-fatal */ }

            _spawnedAgents.Add(spawned);
            return true;
        }

        // ------------------------------------------------------------------ character

        private CharacterObject GetBaseCharacter()
        {
            // Explicit IDs from config / fallback list
            string[] candidates = new[]
            {
                _config.BaseTroopId,
                "imperial_recruit",
                "sturgian_recruit",
                "vlandian_recruit",
                "battanian_volunteer",
                "aserai_recruit",
                "khuzait_nomad",
                "nord_recruit",           // NavalDLC/War Sails
                "naval_recruit",          // NavalDLC generic
            };

            foreach (string id in candidates)
            {
                if (string.IsNullOrWhiteSpace(id)) continue;
                CharacterObject ch = MBObjectManager.Instance.GetObject<CharacterObject>(id.Trim());
                if (ch != null) return ch;
            }

            // Last resort: first regular troop from CharacterObject.All
            // (avoids null crash on exotic module configurations)
            try
            {
                CharacterObject fallback = CharacterObject.All
                    .FirstOrDefault(c => !c.IsHero && c.Occupation == Occupation.Soldier);
                if (fallback != null) return fallback;
            }
            catch { /* API may not be available */ }

            return null;
        }

        // ------------------------------------------------------------------ equipment

        private static Equipment BuildEquipment(
            CharacterObject character, ItemObject item, string slotName)
        {
            // Start from character's base equipment so the mannequin has
            // a proper body and doesn't appear as a floating torso.
            Equipment source = character.FirstBattleEquipment ?? character.Equipment;
            Equipment eq = source != null
                ? new Equipment(source)
                : new Equipment(Equipment.EquipmentType.Battle);

            string s = NormalizeSlot(slotName);

            switch (s)
            {
                case "bodyarmor":
                    // Strip ALL armor slots first so only the body piece shows.
                    StripArmor(eq);
                    eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Body, new EquipmentElement(item));
                    break;

                case "headarmor":
                    eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Head, new EquipmentElement(item));
                    // Remove cape to avoid clipping with some helmets
                    eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Cape, default(EquipmentElement));
                    break;

                case "cape":
                case "shoulder":
                    eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Cape, new EquipmentElement(item));
                    break;

                case "handarmor":
                    eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Gloves, new EquipmentElement(item));
                    break;

                case "legarmor":
                    eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Leg, new EquipmentElement(item));
                    break;

                case "shield":
                    StripWeapons(eq);
                    eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon0, new EquipmentElement(item));
                    break;

                case "horsearmor":
                case "horseharness":
                    // Not captured on a human mannequin. These are skipped by IsSlotSupported().
                    break;
            }

            return eq;
        }

        private static void StripArmor(Equipment eq)
        {
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Head,   default(EquipmentElement));
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Body,   default(EquipmentElement));
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Cape,   default(EquipmentElement));
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Gloves, default(EquipmentElement));
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Leg,    default(EquipmentElement));
        }

        private static void StripWeapons(Equipment eq)
        {
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon0, default(EquipmentElement));
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon1, default(EquipmentElement));
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon2, default(EquipmentElement));
            eq.AddEquipmentToSlotWithoutAgent(EquipmentIndex.Weapon3, default(EquipmentElement));
        }

        // ------------------------------------------------------------------ direction

        private static Vec2 DirectionForView(Vec2 facingPlayer, string view)
        {
            return view switch
            {
                "side"   => Rotate(facingPlayer,  90f),
                "back"   => Rotate(facingPlayer, 180f),
                "detail" => Rotate(facingPlayer,  45f),
                _        => facingPlayer,            // front
            };
        }

        private static Vec2 Rotate(Vec2 v, float deg)
        {
            double rad = deg * Math.PI / 180.0;
            float c = (float)Math.Cos(rad);
            float s = (float)Math.Sin(rad);
            Vec2 r = new Vec2(v.x * c - v.y * s, v.x * s + v.y * c);
            r.Normalize();
            return r;
        }

        // ------------------------------------------------------------------ signals

        private void WriteReadySignal(CaptureItem item, string view, int seq)
        {
            try
            {
                string outputPath = BuildOutputPath(item, view);
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? _config.OutputRoot);

                // Delete stale signals BEFORE writing the new one
                SafeDelete(_config.ReadyPath);
                SafeDelete(_config.AckPath);

                string text =
                    "sequence="    + seq                    + Environment.NewLine +
                    "item_id="     + item.ItemId            + Environment.NewLine +
                    "slot="        + item.Slot              + Environment.NewLine +
                    "view="        + view                   + Environment.NewLine +
                    "order="       + item.Order             + Environment.NewLine +
                    "output_path=" + outputPath             + Environment.NewLine +
                    "display_name="+ item.DisplayName       + Environment.NewLine +
                    "source_module="+ item.SourceModule     + Environment.NewLine +
                    "status=READY"                          + Environment.NewLine;

                AtomicWriteAllText(_config.ReadyPath, text);
            }
            catch (Exception ex)
            {
                HUD("WriteReady error: " + ex.Message);
            }
        }

        private void WriteSkipSignal(CaptureItem item, string view, string reason)
        {
            try
            {
                SafeDelete(_config.ReadyPath);
                SafeDelete(_config.AckPath);

                string text =
                    "sequence=" + (++_sequence) + Environment.NewLine +
                    "item_id="  + item.ItemId   + Environment.NewLine +
                    "slot="     + item.Slot     + Environment.NewLine +
                    "view="     + view          + Environment.NewLine +
                    "order="    + item.Order    + Environment.NewLine +
                    "status=SKIPPED"            + Environment.NewLine +
                    "reason="   + reason        + Environment.NewLine;

                AtomicWriteAllText(_config.ReadyPath, text);
            }
            catch { /* non-fatal */ }
        }

        private string BuildOutputPath(CaptureItem item, string view)
        {
            string filename = item.GetFilename(view);
            if (string.IsNullOrWhiteSpace(filename))
            {
                string slot = NormalizeSlot(item.Slot);
                filename = slot + "__" + item.ItemId + "__" + view + ".png";
            }
            string subDir = _config.GroupByView ? view : "all";
            return Path.Combine(_config.OutputRoot, subDir, filename);
        }

        // ------------------------------------------------------------------ ack

        private bool AckExists() => File.Exists(_config.AckPath);

        private string ReadAckStatus()
        {
            try
            {
                foreach (string raw in File.ReadAllLines(_config.AckPath))
                {
                    string line = raw.Trim();
                    if (line.StartsWith("status=", StringComparison.OrdinalIgnoreCase))
                        return line.Substring("status=".Length).Trim();
                }
            }
            catch { /* non-fatal */ }
            return "DONE";
        }

        private void ConsumeAckAndAdvance()
        {
            try { SafeDelete(_config.AckPath); } catch { /* non-fatal */ }
            _waitingForAck = false;
            AdvanceCursor();
            StopIfSingleShot();
        }

        private void StopIfSingleShot()
        {
            if (_singleShotMode)
            {
                _running = false;
                _singleShotMode = false;
                HUD("Single-shot complete. Current cursor is item #" + (_index + 1) + ".");
            }
        }

        private void AdvanceCursor()
        {
            _viewIndex++;
            if (_viewIndex >= _views.Count)
            {
                _viewIndex = 0;
                _index++;
            }
        }

        // ------------------------------------------------------------------ agents

        private void ClearPreviewAgents(bool announce)
        {
            int cleared = 0;
            foreach (Agent a in _spawnedAgents)
            {
                if (a != null && a.IsActive())
                {
                    try { a.FadeOut(true, false); cleared++; }
                    catch { /* non-fatal */ }
                }
            }
            _spawnedAgents.Clear();
            if (announce) HUD($"Cleared {cleared} preview agent(s).");
        }

        // ------------------------------------------------------------------ directories

        private void EnsureDirectories()
        {
            try
            {
                Directory.CreateDirectory(_config.ConfigRoot);
                Directory.CreateDirectory(_config.SignalDir);
                Directory.CreateDirectory(_config.OutputRoot);
            }
            catch (Exception ex)
            {
                HUD("Dir error: " + ex.Message);
            }
        }

        // ------------------------------------------------------------------ util

        private static bool IsSlotSupported(string slot)
        {
            string s = NormalizeSlot(slot);
            // v4: human mannequin capture supports human armor + shields only.
            // HorseHarness/HorseArmor are still catalogued by Python, but skipped here
            // until a separate horse-preview capture behavior is implemented.
            return s is "bodyarmor" or "headarmor" or "cape" or "shoulder"
                        or "handarmor" or "legarmor" or "shield";
        }

        private static string NormalizeSlot(string value)
        {
            if (value == null) return string.Empty;
            return new string(value.ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray());
        }

        private static void AtomicWriteAllText(string path, string text)
        {
            string dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrWhiteSpace(dir)) Directory.CreateDirectory(dir);
            string tmp = path + ".tmp";
            File.WriteAllText(tmp, text);
            if (File.Exists(path)) File.Delete(path);
            File.Move(tmp, path);
        }

        private static void SafeDelete(string path)
        {
            if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                try { File.Delete(path); } catch { /* non-fatal */ }
        }

        // ================================================================= nested types

        private sealed class CaptureItem
        {
            public int Order;
            public string ItemId;
            public string Slot;
            public string FilenameFront;
            public string FilenameSide;
            public string FilenameBack;
            public string FilenameDetail;
            public string DisplayName;
            public string SourceModule;

            public string GetFilename(string view) => view switch
            {
                "front"  => FilenameFront,
                "side"   => FilenameSide,
                "back"   => FilenameBack,
                "detail" => FilenameDetail,
                _        => FilenameFront,
            };

            public static CaptureItem FromTsv(string line)
            {
                if (string.IsNullOrWhiteSpace(line)) return null;
                string[] p = line.Split('\t');
                if (p.Length < 3) return null;
                // Skip the TSV header row (first column = "order" literal)
                if (p[0].Trim().ToLowerInvariant() == "order") return null;
                int.TryParse(p[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out int order);
                return new CaptureItem
                {
                    Order          = order,
                    ItemId         = Get(p, 1),
                    Slot           = Get(p, 2),
                    FilenameFront  = Get(p, 3),
                    FilenameSide   = Get(p, 4),
                    FilenameBack   = Get(p, 5),
                    FilenameDetail = Get(p, 6),
                    DisplayName    = Get(p, 7),
                    SourceModule   = Get(p, 8),
                };
            }

            private static string Get(string[] a, int i) =>
                i >= 0 && i < a.Length ? a[i] : string.Empty;
        }

        // --------------------------------------------------------------------- config

        private sealed class CaptureConfig
        {
            public string ConfigRoot;
            public string SignalDir;
            public string CaptureQueuePath;
            public string OutputRoot;
            public string ReadyPath;
            public string AckPath;
            public string Views;
            public string BaseTroopId;
            public int    StartIndex;
            public bool   GroupByView;
            public bool   WaitForWatcherAck;
            public float  DelayAfterSpawnSeconds;   // 1.0 s default — time for armor mesh to stream
            public float  BetweenShotsSeconds;      // 0.25 s default — signal handshake gap
            public float  ForwardOffset;
            public float  SideOffset;

            public static CaptureConfig Load()
            {
                string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string root = Path.Combine(
                    docs, "Mount and Blade II Bannerlord", "Configs", "BannerwakeArmorAutoCapture");
                string ini = Path.Combine(root, "config.ini");

                CaptureConfig cfg = new CaptureConfig
                {
                    ConfigRoot             = root,
                    SignalDir              = Path.Combine(root, "signal"),
                    CaptureQueuePath       = Path.Combine(root, "capture_queue.tsv"),
                    OutputRoot             = @"C:\BannerwakeArmorArchive\screenshots",
                    Views                  = "front",
                    BaseTroopId            = "imperial_recruit",
                    StartIndex             = 1,
                    GroupByView            = true,
                    WaitForWatcherAck      = true,
                    DelayAfterSpawnSeconds = 1.0f,   // <-- 1 second render wait
                    BetweenShotsSeconds    = 0.25f,
                    ForwardOffset          = 5.0f,
                    SideOffset             = 0.0f,
                };

                if (File.Exists(ini))
                {
                    foreach (string raw in File.ReadAllLines(ini))
                    {
                        string line = raw.Trim();
                        if (line.Length == 0 || line.StartsWith("#") || !line.Contains("=")) continue;
                        string[] pair = line.Split(new[] { '=' }, 2);
                        string key   = pair[0].Trim().ToLowerInvariant();
                        string value = pair[1].Trim();
                        cfg.Apply(key, value);
                    }
                }

                cfg.ReadyPath = Path.Combine(cfg.SignalDir, "ready.txt");
                cfg.AckPath   = Path.Combine(cfg.SignalDir, "ack.txt");
                return cfg;
            }

            private void Apply(string key, string value)
            {
                switch (key)
                {
                    case "capturequeuepath":       CaptureQueuePath       = Expand(value); break;
                    case "outputroot":             OutputRoot             = Expand(value); break;
                    case "views":                  Views                  = value;         break;
                    case "basetroopid":            BaseTroopId            = value;         break;
                    case "startindex":             StartIndex             = ParseInt(value, StartIndex);     break;
                    case "groupbyview":            GroupByView            = ParseBool(value, GroupByView);   break;
                    case "waitforwatcherack":      WaitForWatcherAck      = ParseBool(value, WaitForWatcherAck); break;
                    case "delayafterspawnseconds": DelayAfterSpawnSeconds = ParseFloat(value, DelayAfterSpawnSeconds); break;
                    case "betweenshotsseconds":    BetweenShotsSeconds    = ParseFloat(value, BetweenShotsSeconds);    break;
                    case "forwardoffset":          ForwardOffset          = ParseFloat(value, ForwardOffset);           break;
                    case "sideoffset":             SideOffset             = ParseFloat(value, SideOffset);              break;
                }
            }

            private static string Expand(string v) => Environment.ExpandEnvironmentVariables(v);
            private static int   ParseInt(string v, int   fb) => int.TryParse(v,   NumberStyles.Integer, CultureInfo.InvariantCulture, out int   r) ? r : fb;
            private static float ParseFloat(string v, float fb) => float.TryParse(v, NumberStyles.Float,   CultureInfo.InvariantCulture, out float r) ? r : fb;
            private static bool  ParseBool(string v, bool  fb)
            {
                if (v.Equals("true",  StringComparison.OrdinalIgnoreCase) || v == "1" || v.Equals("yes", StringComparison.OrdinalIgnoreCase)) return true;
                if (v.Equals("false", StringComparison.OrdinalIgnoreCase) || v == "0" || v.Equals("no",  StringComparison.OrdinalIgnoreCase)) return false;
                return fb;
            }
        }
    }
}
