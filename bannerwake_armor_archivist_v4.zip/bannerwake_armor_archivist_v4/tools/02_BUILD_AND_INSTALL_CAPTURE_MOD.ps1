param(
  [string]$BannerlordDir = "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\BannerwakeArmorAutoCapture")).Path
)

$ErrorActionPreference = "Stop"
$moduleId = "BannerwakeArmorAutoCapture"
$project = Join-Path $ProjectRoot "Source\BannerwakeArmorAutoCapture\BannerwakeArmorAutoCapture.csproj"
$gameModuleDir = Join-Path $BannerlordDir "Modules\$moduleId"
$log = Join-Path (Resolve-Path (Join-Path $PSScriptRoot "..")).Path "install_build.log"

Write-Host "Building Bannerwake Armor AutoCapture v4..."
Write-Host "BannerlordDir: $BannerlordDir"
Write-Host "ProjectRoot:   $ProjectRoot"
Write-Host "Install Dir:   $gameModuleDir"
Write-Host "Build log:     $log"

dotnet build $project -c Release "/p:BannerlordDir=$BannerlordDir" *>&1 | Tee-Object -FilePath $log
if ($LASTEXITCODE -ne 0) { throw "Build failed. See $log" }

if (!(Test-Path $gameModuleDir)) { New-Item -ItemType Directory -Path $gameModuleDir -Force | Out-Null }
Copy-Item -Path (Join-Path $ProjectRoot "SubModule.xml") -Destination (Join-Path $gameModuleDir "SubModule.xml") -Force
if (Test-Path (Join-Path $ProjectRoot "ModuleData")) {
  Copy-Item -Path (Join-Path $ProjectRoot "ModuleData") -Destination $gameModuleDir -Recurse -Force
}
$targetBin = Join-Path $gameModuleDir "bin\Win64_Shipping_Client"
if (!(Test-Path $targetBin)) { New-Item -ItemType Directory -Path $targetBin -Force | Out-Null }
Copy-Item -Path (Join-Path $ProjectRoot "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.dll") -Destination (Join-Path $targetBin "BannerwakeArmorAutoCapture.dll") -Force
if (Test-Path (Join-Path $ProjectRoot "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.pdb")) {
  Copy-Item -Path (Join-Path $ProjectRoot "bin\Win64_Shipping_Client\BannerwakeArmorAutoCapture.pdb") -Destination (Join-Path $targetBin "BannerwakeArmorAutoCapture.pdb") -Force
}

Write-Host ""
Write-Host "Installed to: $gameModuleDir" -ForegroundColor Green
Write-Host "Enable 'Bannerwake Armor AutoCapture' in the Bannerlord launcher."
