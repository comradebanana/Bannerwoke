@echo off
setlocal EnableExtensions
REM Optional later step: re-export a side/back queue after you decide which items are worth deeper capture.
REM This exports all items again by default. For a smaller list, create a filtered capture_queue.json first.
set "OUT=C:\BannerwakeArmorArchive"
set "CONFIG=%USERPROFILE%\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture"
set "PYTHON=python"

where %PYTHON% >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo ERROR: Python was not found.
    pause
    exit /b 1
  )
  set "PYTHON=py -3"
)

cd /d "%~dp0\.."
%PYTHON% bannerwake_armor_archivist.py export-autocapture ^
  --queue "%OUT%\catalog\capture_queue.json" ^
  --out-tsv "%CONFIG%\capture_queue.tsv" ^
  --views side back

powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-Content '%CONFIG%\config.ini') -replace '^Views=.*','Views=side,back' | Set-Content '%CONFIG%\config.ini' -Encoding UTF8"

echo Side/back queue exported. In game press Ctrl+F12 to reload, then Ctrl+F9 to run.
pause
