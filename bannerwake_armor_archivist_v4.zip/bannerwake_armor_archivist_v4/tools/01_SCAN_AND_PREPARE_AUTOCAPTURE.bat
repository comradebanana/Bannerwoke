@echo off
setlocal EnableExtensions

REM Bannerwake Armor Archivist v4 - scan + prepare FRONT-only queue by default.
REM Edit these paths if your Steam library is not on C:.
set "MODULES=C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules"
set "WORKSHOP=C:\Program Files (x86)\Steam\steamapps\workshop\content\261550"
set "OUT=C:\BannerwakeArmorArchive"
set "CONFIG=%USERPROFILE%\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture"
set "PYTHON=python"

where %PYTHON% >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo ERROR: Python was not found. Install Python 3.10+ or add it to PATH.
    pause
    exit /b 1
  )
  set "PYTHON=py -3"
)

cd /d "%~dp0\.."

echo.
echo === STEP 1: Scan Bannerlord modules and build archive data ===
%PYTHON% bannerwake_armor_archivist.py scan ^
  --modules-root "%MODULES%" ^
  --modules-root "%WORKSHOP%" ^
  --out "%OUT%" ^
  --views front
if errorlevel 1 pause && exit /b 1

echo.
echo === STEP 2: Export FRONT-only capture queue for the in-game module ===
if not exist "%CONFIG%" mkdir "%CONFIG%"
%PYTHON% bannerwake_armor_archivist.py export-autocapture ^
  --queue "%OUT%\catalog\capture_queue.json" ^
  --out-tsv "%CONFIG%\capture_queue.tsv" ^
  --views front
if errorlevel 1 pause && exit /b 1

copy /Y "config_templates\config.ini" "%CONFIG%\config.ini" >nul

if exist "%OUT%\gallery\armor_gallery.html" start "" "%OUT%\gallery\armor_gallery.html"

echo.
echo DONE.
echo Queue:  %CONFIG%\capture_queue.tsv
echo Config: %CONFIG%\config.ini
echo Output: %OUT%\screenshots
echo Gallery:%OUT%\gallery\armor_gallery.html
echo.
echo First pass is FRONT ONLY. This is intentional. After you choose good items, do side/back.
echo.
pause
