@echo off
setlocal EnableExtensions
set "MODULES=C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules"
set "WORKSHOP=C:\Program Files (x86)\Steam\steamapps\workshop\content\261550"
set "OUT=C:\BannerwakeArmorArchive"
set "SCREENSHOTS=C:\BannerwakeArmorArchive\screenshots"
set "PYTHON=python"

where %PYTHON% >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo ERROR: Python was not found. Install Python 3.10+ or add it to PATH.
    pause
    exit /b 1
  )
  set "PYTHON=py -3"
)

cd /d "%~dp0\.."
%PYTHON% bannerwake_armor_archivist.py scan ^
  --modules-root "%MODULES%" ^
  --modules-root "%WORKSHOP%" ^
  --screenshots-root "%SCREENSHOTS%" ^
  --out "%OUT%" ^
  --views front

if exist "%OUT%\gallery\armor_gallery.html" start "" "%OUT%\gallery\armor_gallery.html"
pause
