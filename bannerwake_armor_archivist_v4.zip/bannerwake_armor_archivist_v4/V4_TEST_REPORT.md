# Bannerwake Armor Archivist v4 — test report

## What was tested here

The Python/data/gallery side was tested in this environment with a mock Bannerlord-style module tree.

Verified:

- Python syntax compile: OK
- XML scan over mock module folders: OK
- Nested `<ItemComponent><Armor>` parsing: OK
- Shield item parsing: OK
- `UseTeamColor` flag detection: OK
- Pirate/Black Keel recolor heuristic: OK
- Cross-module duplicate item IDs are kept: OK
- Duplicate item IDs no longer steal each other's screenshots: OK
- Module-inclusive screenshot filenames are generated: OK
- Gallery screenshot paths use `../screenshots/...` correctly: OK
- `armor_catalog.csv` generation: OK
- `armor_catalog.json` generation: OK
- `capture_queue.json` generation: OK
- `capture_queue.tsv` export: OK
- `stats` command: OK

## What cannot be fully tested here

The C# Bannerlord in-game module cannot be fully compiled or runtime-tested in this environment because the local Bannerlord v1.4.5 / War Sails DLLs are not available here.

So the required local proof step remains:

```powershell
.\tools\00_PREFLIGHT_CHECK.ps1
```

Only run the install script after preflight says `BUILD OK`.

## v4 hardening changes

- Fixed `Ctrl+F10` single-shot bug. In v3 it spawned an item but did not write `ready.txt` because the normal tick pipeline returned early when not running.
- C# ready/skip signal writes are now temp-file + move instead of direct `File.WriteAllText` to reduce watcher race risk.
- C# now reads watcher `ack.txt`; if watcher reports `status=ERROR`, capture stops instead of silently advancing and losing screenshots.
- Human mannequin capture skips `HorseArmor` / `HorseHarness` for now. Python still catalogues them. A separate horse-preview capture behavior should be built later.
- Python atomic writes now use `os.replace`, which is safer on Windows when overwriting existing output files.
- Screenshot linking now handles cross-module duplicate item IDs safely.
- Default batch workflow is front-only, because capturing front/side/back for thousands of items first is wasteful.
