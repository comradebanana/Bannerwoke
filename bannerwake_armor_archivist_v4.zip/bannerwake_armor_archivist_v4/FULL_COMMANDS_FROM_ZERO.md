# Bannerwake Armor Archivist v4 — full commands from zero

This is the safe order. Do not install the in-game module before preflight passes.

## 0) Extract

Extract the ZIP to:

```txt
C:\BannerwakeArmorArchivist
```

If you use another folder, adjust the `cd` command below.

---

## 1) Open PowerShell

Open normal PowerShell, not administrator unless Windows blocks file copy.

```powershell
cd C:\BannerwakeArmorArchivist
Set-ExecutionPolicy -Scope Process Bypass
```

---

## 2) Check Python

```powershell
python --version
```

If that fails, try:

```powershell
py -3 --version
```

If both fail, install Python 3.10+ first.

---

## 3) Scan armor XML and prepare a FRONT-only queue

Fast/easy way:

```powershell
.\tools\01_SCAN_AND_PREPARE_AUTOCAPTURE.bat
```

Manual equivalent:

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\workshop\content\261550" `
  --out "C:\BannerwakeArmorArchive" `
  --views front
```

Then export the game-readable queue:

```powershell
python .\bannerwake_armor_archivist.py export-autocapture `
  --queue "C:\BannerwakeArmorArchive\catalog\capture_queue.json" `
  --out-tsv "$env:USERPROFILE\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture\capture_queue.tsv" `
  --views front
```

Copy config:

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture"
Copy-Item .\config_templates\config.ini "$env:USERPROFILE\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture\config.ini" -Force
```

---

## 4) Preflight check the Bannerlord C# module

Default Steam path:

```powershell
.\tools\00_PREFLIGHT_CHECK.ps1
```

Different Steam library path example:

```powershell
.\tools\00_PREFLIGHT_CHECK.ps1 -BannerlordDir "D:\SteamLibrary\steamapps\common\Mount & Blade II Bannerlord"
```

Only continue if it prints:

```txt
BUILD OK
```

If it fails, send `preflight_build.log` back for patching.

---

## 5) Build and install the capture module

Default Steam path:

```powershell
.\tools\02_BUILD_AND_INSTALL_CAPTURE_MOD.ps1
```

Different Steam library path example:

```powershell
.\tools\02_BUILD_AND_INSTALL_CAPTURE_MOD.ps1 -BannerlordDir "D:\SteamLibrary\steamapps\common\Mount & Blade II Bannerlord"
```

Expected installed folder:

```txt
C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules\BannerwakeArmorAutoCapture
```

---

## 6) Start the screenshot watcher

Open a second PowerShell window:

```powershell
cd C:\BannerwakeArmorArchivist
Set-ExecutionPolicy -Scope Process Bypass
.\tools\03_START_SCREENSHOT_WATCHER.ps1
```

Keep this window open.

---

## 7) Start Bannerlord

1. Open Bannerlord launcher.
2. Enable `Bannerwake Armor AutoCapture`.
3. Also enable the modules whose armor you want captured.
4. Enter a mission scene where your player exists: training field, custom battle, campaign battle, etc.
5. Stand in a clear flat area.
6. Keep the Bannerlord window visible and not covered.
7. Press:

```txt
Ctrl + F9
```

Hotkeys:

```txt
Ctrl + F9  = start / stop auto capture
Ctrl + F10 = single-shot current item
Ctrl + F11 = clear spawned preview mannequin
Ctrl + F12 = reload config + queue
```

Screenshots should appear here:

```txt
C:\BannerwakeArmorArchive\screenshots\front
```

---

## 8) Rebuild the gallery with screenshots

After capture, run:

```powershell
.\tools\04_REBUILD_GALLERY_AFTER_CAPTURE.bat
```

Manual equivalent:

```powershell
python .\bannerwake_armor_archivist.py scan `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules" `
  --modules-root "C:\Program Files (x86)\Steam\steamapps\workshop\content\261550" `
  --screenshots-root "C:\BannerwakeArmorArchive\screenshots" `
  --out "C:\BannerwakeArmorArchive" `
  --views front
```

Open:

```txt
C:\BannerwakeArmorArchive\gallery\armor_gallery.html
```

---

## 9) Optional later: side/back capture

Only do this after the front gallery exists and you have chosen useful candidates.

```powershell
.\tools\05_EXPORT_SIDE_BACK_QUEUE_AFTER_FILTERING.bat
```

Then in Bannerlord:

```txt
Ctrl + F12  reload queue/config
Ctrl + F9   run capture
```

---

## 10) Resume after crash

Edit:

```txt
%USERPROFILE%\Documents\Mount and Blade II Bannerlord\Configs\BannerwakeArmorAutoCapture\config.ini
```

Set:

```ini
StartIndex=742
```

Then in game:

```txt
Ctrl + F12
Ctrl + F9
```

---

## Outputs to give Claude/Codex

```txt
C:\BannerwakeArmorArchive\catalog\armor_catalog.csv
C:\BannerwakeArmorArchive\catalog\armor_catalog.json
C:\BannerwakeArmorArchive\reports\recolor_candidates.md
C:\BannerwakeArmorArchive\reports\armor_missing_screenshots.md
C:\BannerwakeArmorArchive\gallery\armor_gallery.html
C:\BannerwakeArmorArchive\screenshots\
```
