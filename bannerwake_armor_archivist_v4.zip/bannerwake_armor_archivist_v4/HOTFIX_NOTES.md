# Bannerwake Armor Archivist v4 Hotfix Notes

This package integrates the other model's v4 Python scanner/config/C# behavior, plus two safety hotfixes:

1. `armor_gallery.html` now references screenshots with `../screenshots/...` paths, because the gallery file lives inside the `gallery/` folder. Without this, linked screenshots may not display.
2. Auto-capture screenshot filenames now include the source module name to avoid collisions when multiple modules reuse/override the same item ID.
3. `WaitForWatcherAck=false` now actually advances after writing the ready signal instead of waiting forever for `ack.txt`.

Still required: run `tools\00_PREFLIGHT_CHECK.ps1` on the target PC, because C# API compatibility cannot be proven without local Bannerlord v1.4.5 / War Sails DLLs.
